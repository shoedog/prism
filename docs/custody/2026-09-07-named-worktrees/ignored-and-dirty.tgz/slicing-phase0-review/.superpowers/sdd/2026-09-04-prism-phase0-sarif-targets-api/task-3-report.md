# Task 3 report

## Fix round 1

- Preserved the Task 4-owned `targets::{project, TargetsDocument, TargetsMeta}` re-export deferral and documented it in `src/api/mod.rs`.
- Wrapped facade `callers` and `callees` queries in the re-entrant build pool.
- Split algorithm dispatch into raw and annotated paths so multi-run `results[*].findings` remain raw while flattened `findings` are annotated; removed the CLI clearing projection.
- Added a degraded-fixture regression: red before the fix at the raw-result assertion, green after the fix.
- Verification: API 10 passed; CLI 154 passed; full suite 3,781 passed, 0 failed, 1 ignored; clippy 169 = 169; byte-control 1,504/1,504 identical.
