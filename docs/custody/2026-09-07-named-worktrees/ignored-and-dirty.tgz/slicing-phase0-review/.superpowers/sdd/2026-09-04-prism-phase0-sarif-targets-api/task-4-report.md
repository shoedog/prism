# Task 4 report — `prism targets`

Status: **DONE_WITH_CONCERNS**

## Outcome

Implemented the `prism targets` CLI and the targets contract v1.0 projection without changing the authoritative schema, dependency set, cache constants, or any forbidden analysis/navigation/CPG source. The implementation consumes the Task 3 annotated `ReviewOutcome.run.findings`, preserves algorithm errors, combines parse/load/build warnings before projection warnings, and emits deterministic pretty JSON to stdout or `--out`.

The projection includes:

- schema v1.0 envelope metadata, canonical repo root/SHA, diff SHA/files, build identity, and algorithms in run order;
- the complete §2.4.2 mapping table, bounded `str` parsers, and the 19 permitted `ABSENCE_PAIRS` description rows from `absence_slice.rs:29-160`;
- `parse_quality_for` plus `classify`, severity/tier filters, language lowering, enclosing-function symbol/ranges, sorted/deduplicated related evidence, canonical nine-element JSON-array IDs, first-wins ID dedupe, and deterministic target ordering;
- totality warnings/drops for line zero, repo-escaping paths (POSIX, `..`, Windows drive-rooted, and UNC), path separator normalization, unknown severity, duplicate IDs, and function-name disagreement;
- an independent `TargetsArgs` surface, pre-work algorithm acceptance table, exit codes, and the Task 3 API re-export.

## Fixture and live producer proof

`tests/fixtures/targets/diff.json` marks `client.py` lines 14, 15, 16, 17, and 20 as changed and includes `svc.py` with `diff_lines: []`, causing the review loader to parse the cross-file caller into the CPG. `diff-with-unsupported.json` additionally names `notes.txt`.

The final release-binary fixture probe emitted all five required producers:

- echo: `svc.py:5`, category `missing_error_handling`; the live test selects the echo target and asserts `external_call`, `error_handled`, callee `fetch`, caller symbol/bounds, unlabeled confidence, and candidate tier;
- absence: `client.py:16`, category `missing_counterpart`; the live test selects the file-open finding and asserts `resource_acquire`, `resource_released`, counterpart `close`, kind `filesystem`, exact confidence, asserted tier, and clean parse quality;
- contract: `client.py:14`, categories `contract_violation` and `contract_postcondition_new_null`; the producer-set assertion requires a contract target;
- provenance: `client.py:15`, category `untrusted_origin`; the live test selects the `user_input` description and asserts `other`, `origin_trusted`, and origin detail;
- membrane: `svc.py:5`, category `unprotected_caller`; the live test asserts `boundary` and callee `fetch`.

The symmetry fixture changes only `serialize_x` while leaving `deserialize_x` unchanged. Its finding is named for `serialize_x` but anchored at `client.py:14` inside `fetch`; the v5 test therefore proves `site.symbol == "fetch"`, emits `fetch` bounds, retains counterpart `deserialize_x`, and records the disagreement warning.

## RED evidence

Before implementation:

- `cargo test --test cli targets_test::` selected six tests and failed 0/6 because `targets` was an unknown subcommand (exit 2).
- `cargo test --test integration targets_mapping_test::` failed to compile because `prism::targets` did not exist. Cascading type-inference diagnostics were not treated as independent evidence.

These failures directly established that the CLI and projection API were absent on the base.

## GREEN evidence

- Focused CLI: `cargo test --test cli targets_test::` — 6 passed, 0 failed.
- Focused mapping: `cargo test --test integration targets_mapping_test::` — 9 passed, 0 failed.
- Strict decision unit: `cargo test --bin prism targets_strict_exit_code_tracks_algorithm_errors` — 1 passed, 0 failed.
- Whole CLI: `cargo test --test cli` — 160 passed, 0 failed.
- Whole integration: `cargo test --test integration` — 407 passed, 0 failed, 1 ignored (408 total).
- Full repository, rerun after the final Windows/UNC path hardening with `set -o pipefail`: `cargo test --all-targets --all-features --no-fail-fast` — 29 result lines, **3,797 passed, 0 failed, 1 ignored**. Log: `/tmp/phase0-suite-task4-final.log`. No `FAILED`, panic, or `error: test failed` markers were present.
- `cargo fmt --all -- --check` — passed.
- `cargo clippy --all-targets --all-features` — exit 0; the existing lib-test summary remains 169 warnings (129 duplicates), exactly the supplied baseline. No diagnostic names a Task 4 source or test. Delta: **0**.
- The requested `-D warnings` form remains red on the repository's pre-existing 169-warning baseline (first diagnostic in forbidden `src/algorithms/absence_slice.rs`); those warnings were reported rather than re-baselined or edited.

The in-repo schema checker validates all emitted fixture documents for required fields, closed objects, enums, the 64-lowercase-hex ID pattern, integer minima, and local `$defs` references. A third-party Draft 2020-12 validator is the controller gate in §8.8 and was not run here.

## Byte control

After an immediate release rebuild:

`scripts/phase0-byte-control.sh /Users/wesleyjinks/code/tools/bin/prism-base-c220525 target/release/prism`

passed **1,598/1,598 invocations identical** across stdout, stderr, and exit status. The plan's historical 1,504 count grows by 94 because the script enumerates every checked-in fixture and Task 4 adds two target diff files (2 × 47 invocations). The zero-difference invariant passed. An earlier command using a nonexistent unrelated baseline path was an inadmissible invocation and was discarded before this authoritative same-base run.

## Files and line counts

Production/API:

- `src/targets/mod.rs` — 299
- `src/targets/model.rs` — 103
- `src/targets/mapping.rs` — 226
- `src/main.rs` — 1,360 (213 Task 4 inserted lines before formatting/stat accounting)
- `src/lib.rs` — 92
- `src/api/mod.rs` — 22

Tests/fixtures:

- `tests/cli/targets_test.rs` — 428
- `tests/integration/targets_mapping_test.rs` — 457
- `tests/cli/main.rs` — 14
- `tests/integration/main.rs` — 19
- `tests/fixtures/targets/client.py` — 25
- `tests/fixtures/targets/svc.py` — 5
- `tests/fixtures/targets/notes.txt` — 1
- `tests/fixtures/targets/diff.json` — 14
- `tests/fixtures/targets/diff-with-unsupported.json` — 19

Each new production module is below the 600-line cap.

## Spec/brief differences

- The stale Step 2 wording in the brief and §7.4.8 says symmetry bounds are omitted on a function-name disagreement. Binding v5 in brief Step 4, schema `site` documentation, and design §2.4.2 instead require enclosing-function bounds whenever one exists. The binding v5/spec wins: bounds are emitted and disagreement is warning-only.
- The brief's sample `git add` line omits `src/api/mod.rs`, but its Files/Interfaces section and the controller's explicit Task 4 update require the re-export. The file is included in the exact staged set.
- The DTO signatures use `Option` exactly as specified by the brief, while `project` always emits every schema-required envelope/target field (`producer.build_identity`, `repo.root`, `diff.sha256`, target `description`, and target `parse_quality`).

## Self-review

WRONG findings: none found. The implementation's output was exercised against the live five-producer fixture, exact ID computation, the contract's closed enum/property sets, filters, all normalization/drop cases, warning ownership/order, deterministic ordering, API re-export, and CLI acceptance/load/output paths.

SMELL / concern: design §7.4.6 requests a live CLI run containing a recorded nonfatal algorithm error and `--strict` exit 3. At this base, every algorithm accepted by `targets` has no controllable `Err` after review input/context construction: the default/fallback producers are effectively infallible, while delta and contract swallow unreadable old-tree files and return empty/successful results. Adding a test-only production failure hook would weaken the product boundary. The branch is instead covered by (1) the binary unit test showing non-empty errors + strict maps to exit 3, (2) the projection test proving errors remain in the document, and (3) a live strict successful run proving empty errors remain exit 0. This is not equivalent to the specified live observable and is the reason for `DONE_WITH_CONCERNS`.

Not run: Tier-A accuracy harness, because no call-resolution, navigation-query, CPG-construction, AST, language, cache, or other §6-forbidden source was changed.

## Custody

Base verified immediately before staging: branch `phase0-sarif-targets-api`, HEAD `7a3c04b1bc06b1a38c17d360d1970a50bead9cd0`. The report remains ignored/untracked as required. The single Task 4 commit is `7f3005df6f07790ad35bda5a00f50bae549e33d0`; its required subject and both contiguous trailers were verified with `git show`.

## Fix round 1

Status: **DONE_WITH_CONCERNS**

Applied the Task 4 Opus and terra review findings on top of integrated HEAD `87574bbf1ef068a18a98719bea66c88d30cbd9e5`:

- expanded `ABSENCE_PAIRS` from 19 to all 65 `default_pairs()` descriptions in production order, with filesystem kinds only for unambiguous file/directory/mmap-style rows and counterparts only for closed-table rows with an unambiguous close-call base;
- replaced the hand-copied description list with a population check derived from public `default_pairs()`, pinned the count at 65, and corrected the assertion message;
- added live omitted-`--algorithm` coverage for the five defaults in order and added `review`/`all` exit-1 cases to the acceptance table;
- reordered `TargetsDocument` to schema property order (`schema_version`, `producer`, `repo`, `diff`, `targets`, `errors`, `warnings`) and pinned the serialized order;
- added the unparsed-file bounds warning and made path-normalisation, severity-normalisation, symbol-disagreement, and duplicate-id warnings describe the complete pre-filter population; documented that invariant on `project`;
- retained the helper exit-3 unit coverage and live no-error strict run, and named the non-constructible live recorded-error gap in the CLI test comment.

Red-first control: the new mapping regressions produced 4 failures before production changes (19/65 rows, absent unparsed-file warning, filtered-away symbol/duplicate warnings, and old document field order); 7 other mapping tests passed. The new CLI coverage was already green because it guards correct existing default and rejection behavior.

Final verification:

- `cargo test --test cli targets_test::` — 7 passed, 0 failed;
- `cargo test --test integration targets_mapping_test::` — 11 passed, 0 failed;
- `cargo test --test cli` — 161 passed, 0 failed;
- `cargo fmt --all` and `cargo fmt --all -- --check` — passed;
- `cargo clippy --all-targets --all-features` — exit 0; lib-test stayed at the supplied 169-warning baseline (129 duplicates), no changed-file diagnostic, delta 0;
- `cargo test --all-targets --all-features --no-fail-fast` — 29 result lines, 3,800 passed, 0 failed, 1 ignored; anchored failure-marker scan empty; log `/tmp/phase0-suite-task4-fix1.log`;
- immediate `cargo build --release` followed by `scripts/phase0-byte-control.sh /Users/wesleyjinks/code/tools/bin/prism-base-c220525 target/release/prism` — 1,598/1,598 invocations identical across stdout, stderr, and exit status.

Concern: live `--strict` plus a recorded nonfatal algorithm error remains non-constructible at this base, as ruled in the amended spec. This round retains the helper unit test and live strict no-error coverage; no test-only failure hook was added.

## Fix round 2

Status: **DONE**

Scoped re-review finding (fix round 1): `src/targets/mapping.rs`'s `"Rust Command created but never executed"` row minted `dependency_hint.counterpart = Some("spawn")` against `default_pairs()`'s close patterns `.status()`, `.output()`, `.spawn(` — three distinct calls, an unsafe wrong-direction hint. `"lock without unlock"` had the same shape (`Some("unlock")` against close patterns including `release(`). The controller ruled (spec §2.4.2, commit `dd86ac1`): a `counterpart` may be emitted only when the candidate name is a case-insensitive substring of EVERY `close_patterns` entry of that `PairedPattern`; otherwise `None`.

Applied on top of integrated HEAD `dd86ac1` (spec §2.4.2 commit):

- added `tests/integration/targets_mapping_test.rs::counterpart_is_a_substring_of_every_close_pattern_or_none`, which iterates `ABSENCE_PAIRS` zipped by description against `absence_slice::default_pairs()` and asserts, for every row with `Some(counterpart)`, that the lower-cased counterpart is a substring of every lower-cased `close_patterns` entry of the matching pair;
- added `counterpart_omission_matches_the_spec_2_4_2_examples`, pinning the spec's three named rows directly (`Rust Command created but never executed` → `None`, `lock without unlock` → `None`, `file open without close` → `Some("close")`);
- fixed `ABSENCE_PAIRS` in `src/targets/mapping.rs`: `"lock without unlock"` and `"Rust Command created but never executed"` both changed from `Some(...)` to `None`; no other row violated the rule (verified exhaustively: every remaining `Some(counterpart)` row's close pattern set is either a single close pattern equal to the counterpart plus `(`, or a multi-pattern set where every entry contains the counterpart, e.g. `"close"` in `["close(", "fclose(", "Close(", ".close()"]`);
- updated the pre-existing `missing_close_on_error_path` branch of `maps_all_four_absence_categories_and_closed_pair_rows`, which had hard-coded the now-invalid `Some("unlock")` expectation for the `"lock without unlock"` row, to assert `hint.is_none()` with the spec-§2.4.2 rationale in a comment.

Red-first control: before the table fix, the new `counterpart_is_a_substring_of_every_close_pattern_or_none` test failed naming exactly the two predicted rows:

```
ABSENCE_PAIRS rows violate spec §2.4.2 (counterpart must be a case-insensitive substring of every close pattern): [
    "\"lock without unlock\": counterpart \"unlock\" is not a substring of close pattern \"release(\"",
    "\"Rust Command created but never executed\": counterpart \"spawn\" is not a substring of close pattern \".status()\"",
    "\"Rust Command created but never executed\": counterpart \"spawn\" is not a substring of close pattern \".output()\"",
]
```
`counterpart_omission_matches_the_spec_2_4_2_examples` also failed red (`left: Some("spawn"), right: None`). 11 other mapping tests passed unaffected. Log: `/tmp/phase0-task4-fix2-red.log`.

Rows changed: `"lock without unlock"` (`Some("unlock")` → `None`) and `"Rust Command created but never executed"` (`Some("spawn")` → `None`). No other row was touched.

Green re-run after the fix (13/13 passed, including the two new tests and the updated pre-existing assertion). Log: `/tmp/phase0-task4-fix2-green.log`.

Final verification:

- `cargo test --test integration targets_mapping_test::` — 13 passed, 0 failed (was 11; +2 new tests);
- `cargo test --test cli targets_test::` — 7 passed, 0 failed;
- `cargo fmt --all` — no diff beyond the authored edits;
- `cargo clippy --all-targets --all-features` — `src/targets` diagnostic count 0; lib-test summary line stayed at the baseline `169 warnings (129 duplicates)`, delta 0; log `/tmp/phase0-task4-fix2-clippy.log`;
- `cargo test --all-targets --all-features --no-fail-fast` — `awk '/^test result:/'` over the whole log: 3,802 passed, 0 failed, 1 ignored (baseline 3,800/0/1 plus the 2 new tests); no `FAILED`/`error` lines in the log; log `/tmp/phase0-suite-task4-fix2.log`.
- Byte control: skipped. The table change only alters `dependency_hint.counterpart` values surfaced through the `targets` JSON output; no existing CLI output format (human/SARIF/etc. produced by `prism-base-c220525`) reads or serializes that field, so the byte-identical-output invariant checked by `scripts/phase0-byte-control.sh` is unaffected by this change.

Commit: `08dc291` — `fix(phase0): targets — counterpart only when it is a substring of every close pattern (Task 4 re-review)`. Body cites spec §2.4.2; trailers `Co-Authored-By: Claude Sonnet 5 <noreply@anthropic.com>` and `Claude-Session: https://claude.ai/code/session_015U8HwBTAFzFzqJbbq82JBT`. Files: `src/targets/mapping.rs`, `tests/integration/targets_mapping_test.rs` (2 files changed, 59 insertions, 7 deletions).

Custody: fix commit `84a747c33348499ce3edb54925171747f83d2841`. This ignored/untracked report was intentionally not staged; no push was performed.
