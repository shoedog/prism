### Task 2: SARIF 2.1 serializer and `--format sarif`

**Files:**
- Create: `src/output/sarif.rs` (≤ 600 lines; if the rule `fullDescription` table plus structs approach the cap, move the table to `src/output/sarif_rules.rs`)
- Modify: `src/output/mod.rs` (`pub mod sarif;` + `pub use sarif::{to_sarif, SarifInputs};`), `src/main.rs` (`--format` value_parser; two `"sarif"` arms)
- Create: `tests/cli/sarif_test.rs`; Modify: `tests/cli/main.rs` (`mod sarif_test;`)

**Interfaces:**
- Consumes: Task 1 (`classify`, `parse_quality_for`, `ParseQuality`, `RESOLUTION_MODE`); `crate::slice::{SliceFinding, AlgorithmError, FileParseQuality}`; `crate::cpg_cache::{current_cache_build_identity, binary_input_dirty}`; `env!("CARGO_PKG_VERSION")`, `env!("GIT_SHA")`.
- Produces (used by Task 3's main.rs rewrite and by README):

```rust
pub struct SarifInputs<'a> {
    pub findings: &'a [SliceFinding],
    pub errors: &'a [AlgorithmError],
    pub parse_warnings: &'a [String],
    pub load_warnings: &'a [String],      // files skipped at load (spec §2.3.2); one `warning` notification each
    pub algorithms_run: &'a [String],
    pub parse_quality: &'a BTreeMap<String, FileParseQuality>,   // sparse authoritative map
    pub files: &'a BTreeMap<String, ParsedFile>,                 // parsed files (clean ⇔ parsed and absent from the map)
    pub sources: &'a BTreeMap<String, String>,
}
/// Deterministic SARIF 2.1 document (spec §2.2). Never fails; unrepresentable data is
/// preserved in `properties` and reported as notifications.
pub fn to_sarif(inputs: &SarifInputs) -> serde_json::Value;
pub fn sarif_uri(path: &str) -> (String, bool);   // (encoded uri, escapes_repo_root)
pub fn level_for_severity(severity: &str) -> &'static str;
pub fn fingerprint(finding: &SliceFinding, line_text: &str) -> String;
```

  `to_sarif` returns `serde_json::Value` built from typed `#[derive(Serialize)]` structs (`SarifLog`, `Run`, `Tool`, `Driver`, `Rule`, `Invocation`, `Notification`, `Result`, `Location`, `PhysicalLocation`, `ArtifactLocation`, `Region`, `LogicalLocation`, `RelatedLocation`, `ResultProperties`, `RunProperties`) then `serde_json::to_value`; struct field order = key order. The CLI prints `serde_json::to_string_pretty(&value)? + "\n"`.

- [ ] **Step 1: Write the failing CLI tests** `tests/cli/sarif_test.rs` (copy the `prism_cmd()` and `write_repo(files, diff_files)` helpers from `tests/cli/review_compact_test.rs:16-53` locally — CLI test files keep their own helpers):

```rust
// Fixture A (absence): a.py has `f = open("x")` on line 2 inside `def read():` and never closes it; diff = a.py lines [2].
// Fixture B (echo): client.py `def fetch(): ...` (changed, diff line inside it); svc.py `def handle(): return fetch()` with no try/except.
// Fixture C (degraded): a.py as in A but with a syntax error line `def broken(:` inserted above `read`.

#[test] fn single_algorithm_sarif_shape_and_rule_index() { /* §7.2.1: parse stdout; version == "2.1.0"; driver.name == "prism"; rules.len()==1; rules[0].id == "prism/absence/missing_counterpart"; fullDescription.text non-empty; result level "warning"; uri "a.py"; uriBaseId "%SRCROOT%"; region.startLine == 2; properties.confidence "exact", tier "asserted", parse_quality "clean", resolution_mode "nominal"; for every result: rules[ruleIndex].id == ruleId; runs[0] has no "originalUriBaseIds" key */ }
#[test] fn multi_algorithm_sarif_is_sorted_and_unlabeled_for_cpg() { /* §7.2.2 on fixture B with --algorithm echo,absence */ }
#[test] fn algorithm_error_becomes_notification_and_properties_error() { /* §7.2.3 with --algorithm chop,absence on fixture A */ }
#[test] fn sarif_is_byte_deterministic() { /* §7.2.4 */ }
#[test] fn unknown_format_values_are_rejected() { for v in ["bogus", "Json", ""] { /* exit code 2; stderr contains "invalid value" */ } }
#[test] fn degraded_parse_demotes_to_candidate() { /* §7.2.10 on fixture C: absence result properties.tier == "candidate", parse_quality == "degraded" */ }
```

- [ ] **Step 2: Run to verify it fails**

Run: `cargo test --test cli sarif_test::`
Expected: every test fails (`--format sarif` renders text today → `serde_json::from_slice` fails; `--format bogus` exits 0). Record the outputs.

- [ ] **Step 3: Implement `src/output/sarif.rs`** per spec §2.2:
  - Rule table: `fn rule_description(algorithm: &str, category: &str) -> String` with one sentence per known category (all 29 from `grounding/finding-inventory.md` §4 — copy the category list into the match; `contract_violation` text names both shapes; default: `format!("{algorithm}: {category}")`).
  - Attribution table: `enum Attribution { SameFile, CounterpartFile, Ambiguous }`; `fn attribution(algorithm: &str) -> Attribution` with `SameFile` for `echo|membrane|absence|contract|provenance|taint|peer_consistency`, `CounterpartFile` for `symmetry|primitive`, else `Ambiguous`.
  - `relatedLocations` per §2.2.2: lines (`> 0`, sorted, dedup) attributed by the table; `Ambiguous` with non-empty `related_files` → lines to `properties.related_lines`; files (sorted, dedup) without region.
  - `sarif_uri`: replace `\` with `/`; percent-encode each `/`-separated segment (unreserved `A-Za-z0-9-._~` kept; everything else `%XX` uppercase, UTF-8 bytes); `escapes_repo_root = path.starts_with('/') || Path::new(path).is_absolute() || segments.any(|s| s == "..")`.
  - `level_for_severity`: `concern→error`, `warning→warning`, `suggestion|info→note`, else `error`.
  - `fingerprint`: `sha2::Sha256` over `serde_json::to_vec(&[algorithm, category_or_uncategorized, file, function_name_or_empty, masked_description, line_text])`; `masked_description`: every maximal ASCII-digit run → `#`. Hex lowercase.
  - `properties.severity` always carries the original severity string; `properties.confidence/tier/parse_quality` come from `classify(&f.algorithm, parse_quality_for(f, inputs.parse_quality, inputs.files))`.
  - Notifications also include one `warning` per `load_warnings` entry (text verbatim).
  - Results sorted by `(uri, line, ruleId, message)`; rules sorted by id; `ruleIndex` assigned after sorting.
  - Notifications: one `error` per `AlgorithmError` (`"{algorithm}: {error}"`), one `warning` per parse warning, one `warning` per escaping path (`"path escapes repo root: {path}"`). `executionSuccessful = errors.is_empty()`.
  - `run.properties`: `mapping_version "1"`, `algorithms_run`, `resolution_mode`, `errors` (omit if empty), `prism_build_identity`, `prism_git_sha`, `binary_input_dirty`.
  - Line text: `sources.get(file).and_then(|s| s.lines().nth(line - 1)).map(str::trim).unwrap_or("")` for `line >= 1`.
- [ ] **Step 4: Wire the CLI** in `src/main.rs`:
  - `--format` arg: add `value_parser = ["text", "json", "paper", "review", "callers", "mermaid", "sarif"]` (keep `default_value = "text"` and the doc comment; add `sarif`).
  - In the per-diff-file parse loop (≈`:743-763`) collect a local `load_warnings: Vec<String>` next to the existing unsupported-language `eprintln!`: `format!("skipped unsupported file: {path} (unsupported language)")` — the stderr text stays byte-identical; an unreadable file remains FATAL exactly as today (`fs::read_to_string(..).context(..)?`). This vector is new and only feeds SARIF (Task 3 moves it into `ReviewInputs.load_warnings`).
  - Multi-run `match cli.format.as_str()` (≈`:999`): add arm `"sarif"` building `SarifInputs { findings: &all_findings, errors: &all_errors, parse_warnings: &parse_warnings, load_warnings: &load_warnings, algorithms_run: &algorithms_run, parse_quality: &parse_quality, files: &files, sources: &sources }`, print pretty JSON + newline, then the same trailer as `"json"` (`emit_warnings_to_stderr` + `determine_exit_code`).
  - Single-run `match` (≈`:1124`): arm `"sarif"` with `findings: &result.findings` (already annotated at `:1122`), `errors: &[]`, `parse_warnings: &result.warnings`, `load_warnings: &load_warnings`, `algorithms_run: &[algorithm.name().to_string()]`, same map, files and sources.
- [ ] **Step 5: Unit tests inside `sarif.rs`** (§7.2.6–7.2.9): `line: 0` → no `region`; attribution cases (`absence` lines 5,0,3,5 + `b.py`; `symmetry` lines 10,20 in `b.py`; `callback_dispatcher` → files only + `properties.related_lines`); severity map incl. `"critical"` → `"error"` with `properties.severity == "critical"`; fingerprint invariance under `(line 12)`→`(line 13)` and sensitivity to `line_text`/`function_name`; `sarif_uri` cases (`dir with space/a b.py` → `dir%20with%20space/a%20b.py`; `a\\b.py` → `a/b.py`; `../x.py` → `escapes == true`).
- [ ] **Step 6: Run to verify it passes**

Run: `cargo test --test cli sarif_test:: && cargo test --lib output::sarif`
Expected: all pass. Then `cargo test --test cli` (whole CLI target) — the format allow-list must not break existing tests; if any existing test passes an invalid format value, report it (do not "fix" the test silently).

- [ ] **Step 7: fmt + clippy + full suite + commit**

```bash
cargo fmt --all && cargo clippy --all-targets --all-features -- -D warnings
cargo test --all-targets --all-features --no-fail-fast 2>&1 | tee /tmp/phase0-suite-task2.log; awk '/^test result:/' /tmp/phase0-suite-task2.log
git add src/output/sarif.rs src/output/mod.rs src/main.rs tests/cli/sarif_test.rs tests/cli/main.rs
git commit -m "feat(phase0): --format sarif (SARIF 2.1 serializer) and --format allow-list (spec §2.2)"
```

---

