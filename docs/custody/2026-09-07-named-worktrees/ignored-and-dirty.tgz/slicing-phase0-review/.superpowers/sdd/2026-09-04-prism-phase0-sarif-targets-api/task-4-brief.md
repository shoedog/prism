### Task 4: `prism targets` — projection into the targets contract

**Files:**
- Create: `src/targets/mod.rs`, `src/targets/model.rs`, `src/targets/mapping.rs`
- Modify: `src/lib.rs` (`pub mod targets;`), `src/main.rs` (`Command::Targets(TargetsArgs)` + `run_targets`), `src/api/mod.rs` (add the spec §2.3.2 re-export `pub use crate::targets::{project, TargetsDocument, TargetsMeta};` — deferred from Task 3 by controller ruling because the module did not exist yet)
- Create: `tests/fixtures/targets/` (repo: `client.py`, `svc.py`, `diff.json`, and `old/` copy for `--old-repo` if used), `tests/cli/targets_test.rs`, `tests/integration/targets_mapping_test.rs`; Modify: `tests/cli/main.rs`, `tests/integration/main.rs`
- Read-only reference: `docs/contracts/targets.schema.json` (authoritative; do not edit)

**Interfaces:**
- Consumes: `prism::api::{review, ReviewOptions, ReviewOutcome, ReviewInputs, AlgorithmParams, build_info}`, Task 1 `classify` + `parse_quality_for`, `crate::output::severity_rank`, `ParsedFile::{function_node_spanning, node_line_range}` (public; `src/ast.rs:584`) plus the node's name (the same helpers the file uses for `enclosing_function`), `Language::{from_path, all}`.
- Produces:

```rust
// src/targets/model.rs — Serialize + Deserialize DTOs mirroring the schema; field order = schema order
pub struct TargetsDocument { pub schema_version: String, pub producer: Producer, pub repo: Option<Repo>, pub diff: Option<Diff>,
                             pub errors: Vec<AlgorithmError> /* skip if empty */, pub warnings: Vec<String> /* skip if empty */, pub targets: Vec<Target> }
pub struct Producer { pub tool: String, pub version: String, pub resolution_mode: String, pub build_identity: Option<String>, pub algorithms: Vec<String> }
pub struct Repo { pub root: Option<String>, pub sha: Option<String> }
pub struct Diff { pub sha256: Option<String>, pub files: Vec<String> }
pub struct Target { pub id: String, pub site: Site, pub kind: String, pub category: String, pub expected: Expected,
                    pub dependency_hint: Option<DependencyHint>, pub source_algorithm: String, pub confidence: FindingConfidence,
                    pub tier: FindingTier, pub severity: String, pub description: Option<String>, pub related: Option<Related>, pub parse_quality: Option<String> }
pub struct Site { pub file: String, pub line: usize, pub symbol: Option<String>, pub function_start_line: Option<usize>, pub function_end_line: Option<usize>, pub language: Option<String> }
pub struct Expected { pub property: String, pub detail: Option<String> }
pub struct DependencyHint { pub kind: Option<String>, pub callee: Option<String>, pub counterpart: Option<String> }
pub struct Related { pub lines: Vec<usize>, pub files: Vec<String> }

// src/targets/mapping.rs
pub struct Mapped { pub kind: &'static str, pub property: &'static str, pub detail: Option<String>, pub hint: Option<DependencyHint> }
pub fn map_finding(finding: &SliceFinding) -> Mapped;            // the spec §2.4.2 table; bounded str parsers; no regex
pub fn language_tag(lang: Language) -> &'static str;             // the lowering table
pub const ABSENCE_PAIRS: &[(&str, Option<&str>, Option<&str>)];  // (PairedPattern.description literal, counterpart, kind)

// src/targets/mod.rs
pub struct TargetsMeta { pub algorithms_run: Vec<String>, pub repo_root: PathBuf, pub repo_sha: Option<String>,
                         pub errors: Vec<AlgorithmError>, pub run_warnings: Vec<String> /* parse ++ load ++ build, assembled by the CLI */,
                         pub min_severity_rank: u8, pub min_tier: FindingTier }   // project() emits warnings = run_warnings ++ its own projection warnings
pub fn project(findings: &[SliceFinding], inputs: &ReviewInputs, meta: &TargetsMeta) -> TargetsDocument;
pub fn target_id(file: &str, line: usize, symbol: Option<&str>, algorithm: &str, category: &str, description: &str, severity: &str, related_lines_sorted: &[usize], related_files_sorted: &[String]) -> String;   // sha256 of the 9-element canonical JSON array
```

- [ ] **Step 1: Build the fixture** `tests/fixtures/targets/` so that all five default producers emit at least one finding (§7.4.1), plus a `serialize_x`/`deserialize_x` pair with only one changed (symmetry, run separately with `--algorithm symmetry`, §7.4.3) and a `notes.txt` named in a second diff file `diff-with-unsupported.json` (§7.4.7b). Iterate with the release binary: `target/release/prism --repo tests/fixtures/targets --diff tests/fixtures/targets/diff.json --algorithm echo,absence,contract,provenance,membrane --format json | jq '.all_findings[] | {algorithm, category, file, line}'`. Known triggers (grounding/finding-inventory.md): echo — a changed function `fetch` in `client.py` called from `svc.py` as `return fetch()` with no error handling; membrane — the same cross-file call site (the caller is in another file); absence — `f = open("x")` never closed, on a diff line; contract — a guard clause (`if not x: return None`) on a diff line inside a function that also has non-null returns; provenance — `v = request.args.get("q")` on a diff line. Record which lines are on the diff in `diff.json` and, in a `README` comment inside `tests/cli/targets_test.rs`, which assertion discriminates each producer. If a producer cannot be triggered after a bounded effort (≤ 45 min), report DONE_WITH_CONCERNS naming it — do not weaken §7.4.1 silently.
- [ ] **Step 2: Write the failing tests** — `tests/cli/targets_test.rs` (§7.4.1–7.4.7; include the in-repo structural checker `fn check_against_schema(doc: &Value, schema: &Value)` that walks `required`, `enum`, `pattern` for `id`, `additionalProperties: false`, `minimum` on integers, and `$ref` into `$defs`) and `tests/integration/targets_mapping_test.rs` (§7.4.8: one case per mapping row with the verbatim description formats from `grounding/finding-inventory.md` §1; `line: 0` drop + warning; duplicate id + warning; symmetry bounds omitted + warning; `Language::all()` lowering ⊆ schema enum read from `docs/contracts/targets.schema.json`; `a\\b.py` → `a/b.py`; `../x.py` warning; `category: None` → `uncategorized`; severity `critical` → `concern` + warning; `contract_violation` both shapes + unrecognised → `unknown`).
- [ ] **Step 3: Run to verify it fails** — `cargo test --test cli targets_test::` (unknown subcommand → exit 2) and `cargo test --test integration targets_mapping_test::` (compile error). Record.
- [ ] **Step 4: Implement** `src/targets/*` per spec §2.4.2 (all rules, v5 wording: `site.symbol` = innermost enclosing function name when known and bounds ALWAYS emitted when that function exists, warning on disagreement with `function_name`; absolute/`..` paths → finding dropped + warning; `parse_quality_for` for confidence/tier/parse_quality; document `warnings` = parse_warnings ++ load_warnings ++ projection warnings; `ABSENCE_PAIRS` rows copied from the `PairedPattern` descriptions in `src/algorithms/absence_slice.rs:29-160` — read the file; one row per literal; `counterpart` only where exactly one close-call base exists) and the subcommand in `src/main.rs`:
  - `TargetsArgs { repo, diff, algorithm (default "echo,absence,contract,provenance,membrane"), files, compile_commands, scoped_cpg, cache_dir, no_cache, old_repo, min_severity (value_parser four values, default "info"), min_tier (value_parser ["asserted","candidate"], default "candidate"), strict, out, format (value_parser ["json"], default "json") }`.
  - Pre-flight acceptance table (spec §2.4.1) before any loading; error messages verbatim from the spec.
  - `repo_sha`: `std::process::Command::new("git").args(["rev-parse","HEAD"]).current_dir(&repo)`; `None` on any failure.
  - Exit codes: 0; 3 with `--strict` and non-empty `errors`; 1 on load/build error; 2 clap.
- [ ] **Step 5: Run to verify it passes** — both test modules green; then re-run `scripts/phase0-byte-control.sh` (must still be zero diffs) and `cargo test --test cli`.
- [ ] **Step 6: fmt + clippy + full suite + commit**

```bash
cargo fmt --all && cargo clippy --all-targets --all-features -- -D warnings
cargo test --all-targets --all-features --no-fail-fast 2>&1 | tee /tmp/phase0-suite-task4.log; awk '/^test result:/' /tmp/phase0-suite-task4.log
git add src/targets src/lib.rs src/main.rs tests/fixtures/targets tests/cli/targets_test.rs tests/cli/main.rs tests/integration/targets_mapping_test.rs tests/integration/main.rs
git commit -m "feat(phase0): prism targets — projection into the targets contract v1.0 (spec §2.4)"
```

---

