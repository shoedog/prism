# Task 2 report — SARIF 2.1 serializer and `--format sarif`

Branch `phase0-sarif-targets-api`; base `cd1d696`; commit **`68c74d4`** —
`feat(phase0): --format sarif (SARIF 2.1 serializer) and --format allow-list (spec §2.2)`.

## 1. What was built

| File | Lines | Role |
|---|---|---|
| `src/output/sarif.rs` (new) | 599 | Document model (16 `#[derive(Serialize)]` structs) + assembly (`to_sarif`, `build_result`, `related`, `sort_key`, `physical_location`), `SarifInputs`, re-exports, §7.2.6 unit tests |
| `src/output/sarif_rules.rs` (new) | 476 | Pure mapping tables + their unit tests: `rule_description` (29 categories), `Attribution`/`attribution`, `level_for_severity`, `sarif_uri`/`encode_segment`, `fingerprint`/`mask_digits`, `line_text_of`, `UNCATEGORIZED` |
| `src/output/mod.rs` | +3 | `pub mod sarif; mod sarif_rules;` + `pub use sarif::{to_sarif, SarifInputs};` |
| `src/main.rs` | +65/−2 | `--format` `value_parser` allow-list (+`sarif`), `load_warnings` collection in the per-diff-file parse loop, `"sarif"` arm in BOTH `match cli.format.as_str()` sites |
| `tests/cli/sarif_test.rs` (new) | 599 | 8 e2e tests (§7.2.1–5, §7.2.10, load warnings, allow-list positive control) + `mod document` with 3 in-process tests (§7.2.7/§7.2.9 doc-level, uncategorized) |
| `tests/cli/main.rs` | +1 | `mod sarif_test;` |

Public API exactly as the brief specifies (`to_sarif`, `SarifInputs`, `sarif_uri`,
`level_for_severity`, `fingerprint` — the last three re-exported from `sarif_rules`
through `pub use`, so `prism::output::sarif::level_for_severity` resolves).

Behaviour implemented per spec §2.2: one result per finding (nothing dropped),
`ruleId = prism/{algorithm}/{category|uncategorized}`, conservative severity→level
map with the original in `properties.severity`, `region` omitted at `line == 0`,
`logicalLocations` from `function_name`, per-algorithm related-line attribution with
unattributable lines preserved in `properties.related_lines`, `partialFingerprints`
`prism/finding/v1` over the canonical 6-string JSON array with masked digit runs,
notifications for algorithm errors / parse warnings / load warnings / escaping paths,
`executionSuccessful = errors.is_empty()`, `run.properties` with `mapping_version`,
`algorithms_run`, `resolution_mode`, optional `errors`, and the three build-specific
fields. No `originalUriBaseIds`. `uriBaseId: "%SRCROOT%"`. No new dependencies.

## 2. TDD evidence

### RED (before implementation)

`cargo test --test cli sarif_test::`

```
test result: FAILED. 1 passed; 7 failed; 0 ignored; 0 measured; 143 filtered out
failures:
    sarif_test::algorithm_error_becomes_notification_and_properties_error
    sarif_test::degraded_parse_demotes_to_candidate
    sarif_test::multi_algorithm_sarif_is_sorted_and_unlabeled_for_cpg
    sarif_test::sarif_is_byte_deterministic
    sarif_test::single_algorithm_sarif_shape_and_rule_index
    sarif_test::skipped_unsupported_file_becomes_a_notification
    sarif_test::unknown_format_values_are_rejected
```

Two distinct RED mechanisms, both as predicted by the brief:

```
panicked at tests/cli/sarif_test.rs:115:9:
stdout is not JSON (expected value at line 1 column 1);
stdout="# Block 0 [M] a.py\n    1|def read():\n+   2|    f = open(\"x\")\n..."
```
(`--format sarif` fell through to the text renderer), and

```
panicked at tests/cli/sarif_test.rs:368:9:
assertion `left == right` failed: --format "bogus" must be a clap parse error
  left: Some(0)
 right: Some(2)
```

The one test that passed at RED — `allow_listed_format_values_are_accepted` — is a
deliberate *positive control* (no allow-list existed, so nothing could be rejected);
it guards against the allow-list narrowing the supported set and is expected to pass
both before and after. Recorded rather than silently counted as coverage.

### GREEN (after implementation)

`cargo test --lib output::sarif` → **13 passed; 0 failed** (4 in `sarif::tests`,
9 in `sarif_rules::tests`).

`cargo test --test cli sarif_test::` → **11 passed; 0 failed**:

```
test sarif_test::document::escaping_path_is_emitted_with_one_warning_notification ... ok
test sarif_test::document::unknown_severity_becomes_error_and_keeps_the_original ... ok
test sarif_test::document::missing_category_becomes_uncategorized_and_empty_collections_are_omitted ... ok
test sarif_test::unknown_format_values_are_rejected ... ok
test sarif_test::degraded_parse_demotes_to_candidate ... ok
test sarif_test::algorithm_error_becomes_notification_and_properties_error ... ok
test sarif_test::single_algorithm_sarif_shape_and_rule_index ... ok
test sarif_test::skipped_unsupported_file_becomes_a_notification ... ok
test sarif_test::multi_algorithm_sarif_is_sorted_and_unlabeled_for_cpg ... ok
test sarif_test::sarif_is_byte_deterministic ... ok
test sarif_test::allow_listed_format_values_are_accepted ... ok
```

`cargo test --test cli` (whole target, allow-list regression check) →
**151 passed; 0 failed**. **No existing test passes an invalid top-level `--format`
value.** The three `--format jsn` uses in `tests/cli/nav_compat_test.rs` (lines 182,
319) are on the **`nav` subcommand's own `--format`**, a different argument that this
task did not touch; they already expected exit 2 and still do.

### Coverage of every numbered §7.2 observable

| Spec | Asserted by |
|---|---|
| 7.2.1 | `sarif_test::single_algorithm_sarif_shape_and_rule_index` (version, `$schema`, driver name, one rule + non-empty `fullDescription`, level, uri, `uriBaseId`, `startLine`, all six `properties`, ruleIndex correspondence **for every result**, no `originalUriBaseIds`, build-specific keys present-but-uncompared) |
| 7.2.2 | `sarif_test::multi_algorithm_sarif_is_sorted_and_unlabeled_for_cpg` (echo result `unlabeled`/`candidate`, `algorithms_run == ["EchoSlice","AbsenceSlice"]`, `(uri,startLine,ruleId)` non-decreasing, rules sorted by id, ruleIndex correspondence) |
| 7.2.3 | `sarif_test::algorithm_error_becomes_notification_and_properties_error` |
| 7.2.4 | `sarif_test::sarif_is_byte_deterministic` (two runs, byte equality, trailing newline) |
| 7.2.5 | `sarif_test::unknown_format_values_are_rejected` (see divergence §5.1) |
| 7.2.6 | `sarif::tests::{line_zero_omits_the_region, same_file_attribution_locates_lines_in_the_finding_file, counterpart_attribution_locates_lines_in_the_related_file, ambiguous_attribution_preserves_lines_it_cannot_place}` — all four sub-cases incl. ids `0,1,2` and the sorted/dedup/zero-dropped line set |
| 7.2.7 | `sarif_rules::tests::severity_maps_to_level` (four vocabulary values + `critical` + `""`) and `sarif_test::document::unknown_severity_becomes_error_and_keeps_the_original` (`properties.severity == "critical"`) |
| 7.2.8 | `sarif_rules::tests::fingerprint_is_line_shift_stable_and_evidence_sensitive` (`(line 12)`/`(line 13)` equal; differing `line_text` and `function_name` differ; 64 lowercase hex chars) |
| 7.2.9 | `sarif_rules::tests::uri_encoding_keeps_unreserved_and_normalises_separators` + `sarif_test::document::escaping_path_is_emitted_with_one_warning_notification` (`../x.py` emitted **and** one warning, deduplicated across findings) |
| 7.2.10 | `sarif_test::degraded_parse_demotes_to_candidate` |

Extra tests beyond the numbered set: load-warning notification e2e,
allow-list positive control, `mask_digits`, `attribution` table verbatim,
`line_text_of`, all 29 rule sentences present + fallback + `contract_violation`
naming both shapes, empty-collection omission.

## 3. Fixtures (empirically derived, not assumed)

- **A (absence)** `a.py`: `def read(): / f = open("x") / return f`, diff `[2]`.
  Produces **four** `missing_counterpart` findings (four pattern families match
  `open(`), all at `a.py:2` — hence "one distinct ruleId ⇒ one rule" in §7.2.1 is
  asserted as `rules.len() == 1` with a per-result loop.
- **B (echo)** `client.py` (`fetch` with `open` + `return`), `svc.py`
  (`handle` calling `fetch()` unguarded), diff `client.py [2,3]` **and
  `svc.py []`**. The empty-diff-line entry is required: the CLI builds the CPG
  from the diff's files only, so a caller outside the diff has no call edge and
  echo emitted nothing. Verified by probing `--format callers` (`"callers": []`)
  before adding `svc.py`. Diff line 3 is needed because echo gates on
  `change_touches_return` (`echo_slice.rs:134-142`).
- **C (degraded)** fixture A with `def broken(:` prepended, diff `[3]`.
  Confirmed via `--format json` that `a.py` grades `degraded` (not `poor`).

## 4. Verification

### Full suite (before the commit)

`cargo test --all-targets --all-features --no-fail-fast`, totals by awk over the
whole log (`/private/tmp/.../phase0-suite-task2.log`):

```
awk '/^test result:/ {p+=$4; f+=$6; i+=$8; n+=1} END {printf "suites=%d passed=%d failed=%d ignored=%d\n", n,p,f,i}'
suites=29 passed=3771 failed=0 ignored=1
```

Exit status 0; zero `FAILED`/`error` lines in the log. The single ignored test is
pre-existing. Nothing was excluded — the whole suite ran.

### `cargo fmt --all`

Clean (run before the commit; the committed files are the formatted ones).

### Clippy delta

The crate has 169 pre-existing lint errors under `-D warnings`; `grep -c '^error'`
on the base log is **171** (169 + the two `could not compile` summary lines).

*Probe 1 — `-D warnings` (matches the brief's gate):*

```
cargo clippy --all-targets --all-features -- -D warnings
total ^error lines: 171        (base: 171)
grep -c "src/output/sarif": 0  (base: 0)
diff <(base ^error | sort | uniq -c) <(after ^error | sort | uniq -c)  ->  IDENTICAL
```

*Probe 1 is not admissible for the test files.* The log shows only
`could not compile prism (lib)` and `(lib test)` and **zero** `--> tests/` references
— under `-D warnings` the lib fails first and clippy never analyses the integration
test targets. Claiming "my test file adds no warnings" from that run would be
evidence about a probe that never ran.

*Probe 2 — same command without `-D warnings`, so compilation proceeds to every target:*

```
cargo clippy --all-targets --all-features        (exit 0)
"--> tests/" references: 82                      <- test targets WERE analysed
tests/cli/sarif_test warnings: 0
src/output/sarif      warnings: 0   (both sarif.rs and sarif_rules.rs)
src/main.rs           warnings: 3
```

The three `src/main.rs` warnings are `needless_borrow` at post-change lines 997, 1159,
1348. **Same-environment control:** those exact expressions exist verbatim in the base
file at lines 983, 1120, 1287 (`git show cd1d696:src/main.rs | grep -n ...`), i.e. they
are the same three sites shifted by my insertions, not new. `git diff -U0 src/main.rs`
shows my hunks at 66, 748, 763, 1092, 1200 — none of them contains those lines.

One clippy error WAS introduced during implementation and fixed before the commit:
`unnecessary_lazy_evaluations` on `serde_json::to_value(&log).unwrap_or_else(|_| Value::Null)`
→ `unwrap_or(Value::Null)`. Caught by probe 1 (count went 171 → 172), then back to 171.

### File-length limit (CLAUDE.md §7, "under 600 lines")

`src/output/sarif.rs` 599, `src/output/sarif_rules.rs` 476,
`tests/cli/sarif_test.rs` 599. All under the cap, but two of them with only one
line of headroom — see Concerns.

## 5. Spec-vs-brief / spec-vs-reality divergences resolved

**5.1 `--format ""` does not say "invalid value" (spec §7.2.5).** Reality: clap
rejects an empty value on a possible-values argument with
`error: a value is required for '--format <FORMAT>' but none was supplied` plus the
possible-values list, exit 2, empty stdout.

Hypothesis/probe log:
- H: the message differs because of clap's empty-value handling, not my argument config.
- Falsifier: a *pre-existing* argument in this crate that uses the same
  `value_parser = [...]` array form would say "invalid value" for `""`.
- Probe: `--review-min-severity ""` (allow-list added long before this task, untouched).
- Result: **identical** message shape (`a value is required ... [possible values: info, suggestion, warning, concern]`) → H supported; the alternative cause (my array-form
  `value_parser` vs `PossibleValuesParser`) is ruled out because the control uses the
  same form.

Resolution: the test asserts exit 2 + empty stdout + the allow-list in stderr for all
five bad values, `"invalid value"` for the four non-empty ones, and
`"a value is required"` for `""`. The spec's substantive observable (rejected, exit 2,
nothing rendered) holds for every value; only the literal string differs, and it is not
achievable without changing clap. **Not silently papered over — asserted explicitly and
documented in the test's doc comment.**

**5.2 Key ORDER is alphabetical, not struct field order (brief note, §2.2 preamble).**
The brief says "struct field order = key order". `serde_json::Value::Object` is a
`BTreeMap` unless the `preserve_order` feature is on, and it is not on in this crate;
enabling it would be a forbidden `Cargo.toml` dependency change (spec §6). Observed
output is alphabetically keyed (`$schema`, `runs`, … `version` last). This violates no
spec observable: §2.2.4's ordering requirements are about the `results`, `rules` and
`relatedLocations` **arrays**, all of which are sorted as specified; JSON object key
order carries no meaning and is deterministic either way. The typed structs still fix
the key set and every `skip_serializing_if` omission. The module docs now state this
explicitly rather than repeating the brief's incorrect claim.

**5.3 `src/output/sarif_rules.rs` is not in spec §6's "New" file list.** The brief
authorises it ("if the rule `fullDescription` table plus structs approach the cap, move
the table to `src/output/sarif_rules.rs`") and the task instructions list it as
permitted. It is not in §6's Forbidden list. It was needed: a single file would have
been ~1050 lines. Its scope grew beyond the brief's "just the table" to all the pure
mapping functions, because the table alone did not bring `sarif.rs` under 600 —
see Concerns.

**5.4 §7.2.6–7.2.9 test placement.** Spec §7.2's header assigns the whole section to
`tests/cli/sarif_test.rs`; the brief's Step 5 asks for §7.2.6–7.2.9 as unit tests inside
`sarif.rs`. Both were honoured where they fit under the line cap: §7.2.6 and the
pure-function halves of §7.2.7–7.2.9 are in-module unit tests (`cargo test --lib
output::sarif` passes, as the brief's Step 6 requires); the document-level halves of
§7.2.7/§7.2.9 are in `tests/cli/sarif_test.rs::document` (in-process, public API only —
the same pattern `tests/cli/nav_compat_test.rs` already uses). Every numbered
observable is asserted somewhere.

**5.5 Struct named `SarifResult`, not `Result`.** The brief lists `Result` among the
struct names; defining `struct Result` would shadow the prelude alias in the module.
Private type, no contract impact.

## 6. Self-review

- **Nothing dropped (§5.3).** Every finding becomes a result (`inputs.findings.iter().map(...)`,
  no filter). Escaping paths are emitted *and* warned. Unattributable lines go to
  `properties.related_lines`. `related_files` are always echoed to `properties`.
  Covered by tests.
- **Confidence never over-claims (§5.1).** `confidence`/`tier` come only from
  `classify(&f.algorithm, parse_quality_for(f, map, files))` — Task 1's single source.
  The serializer never reads `finding.parse_quality` (the legacy annotated field), so
  the sparse-map semantics (absent + parsed = clean, absent + unparsed = unknown) apply.
  §7.2.10 pins the degraded demotion end to end.
- **Unknown severities louder (§5.5).** `_ => "error"`, original kept. Tested with
  `"critical"` and `""`.
- **Determinism.** `sort_by` is stable; the sort key includes `message.text`, so the
  four identical-location absence findings order deterministically by message. `rules`
  come from a `BTreeMap`, so they are sorted by construction and `ruleIndex` is derived
  from that same ordering (no chance of drift). Byte determinism pinned by §7.2.4.
- **`line_host` subtlety.** A related file that hosts the line locations is not repeated
  as a region-less entry, but only when line locations were actually emitted
  (`(!locations.is_empty()).then_some(host).flatten()`). Without that guard, a symmetry
  finding with a counterpart file and *no* related lines would lose the file entirely.
- **Existing formats untouched.** The only shared-path change is the `load_warnings`
  push next to the existing `eprintln!` (stderr text byte-identical) and the clap
  allow-list. `--format callers` still returns early before both match sites. The 151-test
  CLI target, including the byte-pinned `nav_compat_test`, passes.
- **Unreadable files stay fatal**, as required — `fs::read_to_string(..).context(..)?`
  is unchanged; only the *unsupported-language* branch gained a warning.

## 7. Concerns

1. **Line-cap headroom is one line.** `src/output/sarif.rs` and
   `tests/cli/sarif_test.rs` are both exactly 599. Any future edit to either — or a
   rustfmt version bump — breaks the 600-line convention immediately. The structural
   cause is that the SARIF document model (16 serde structs ≈ 155 lines) plus assembly
   plus tests genuinely exceeds one file's budget; the permitted-file list allowed only
   one companion module. If Task 3 or review touches these files, budget a further split
   (e.g. `sarif_model.rs`) rather than shaving comments.
2. **`sarif_rules.rs` is broader than the brief described.** It is "the mapping tables"
   module, not only the `fullDescription` table. This is disclosed rather than hidden;
   the alternative was a 1050-line `sarif.rs`.
3. **Fixture B needs `svc.py` in the diff spec with empty `diff_lines`.** That is an
   artefact of the CLI building the CPG from the diff's files, not from the repo. It
   makes the echo fixture slightly unnatural and is documented in the fixture's doc
   comment. If Task 3's `api::review` changes CPG scope, this fixture may need revisiting.
4. **Absence emits four findings for one `open(` call** (four overlapping pattern
   families). Not caused by this task, but it means a real SARIF report will show four
   near-duplicate alerts for one leak, all sharing a rule and differing only in message
   — and, because `partialFingerprints` includes the description, four distinct
   fingerprints. Worth a follow-up outside this task.
5. **`preserve_order`.** If any future dependency enables `serde_json/preserve_order`,
   key order silently changes from alphabetical to struct order. Still deterministic and
   still valid SARIF; no test depends on it. Noted in the module docs.
6. **`properties.related_files` is emitted verbatim** (source order), not sorted, so it
   mirrors the `json` format's field exactly. `relatedLocations` file entries *are*
   sorted. Deliberate, but the two orders can differ for a finding with unsorted
   `related_files`; no current algorithm produces one.

---

# Fix round 1/5 — review follow-ups

Commit **`f627d0a`** — `refactor(phase0): split SARIF model and tests under the
600-line cap; pin message sort key`, on top of `68c74d4` (+ the two spec docs
commits `1b98e24`, `4be0a36` that amended §6 to permit the new files).
`src/main.rs` is **untouched** by this round (`git diff --stat HEAD -- src/main.rs`
is empty), so per the coordinator's instruction the full suite was skipped and the
whole `cargo test --test cli` target run instead.

## Important 1 — file-size ceiling

Two new files; the four SARIF files that were at or near the cap now have real
headroom.

| File | Before | After |
|---|---|---|
| `src/output/sarif.rs` | 599 | **448** |
| `src/output/sarif_model.rs` (new) | — | **171** |
| `src/output/sarif_rules.rs` (untouched) | 476 | 476 |
| `tests/cli/sarif_test.rs` | 599 | **445** |
| `tests/cli/sarif_shape_test.rs` (new) | — | **288** |

- **`src/output/sarif_model.rs`**: the 18 `#[derive(Serialize)]` document structs
  moved verbatim out of `sarif.rs:61-217`, made `pub` inside a **private**
  `mod sarif_model;` (declared in `src/output/mod.rs`), so none of them appears in
  a public signature. `sarif.rs` imports them by an explicit name list, not a glob.
- **Stale banner fixed.** The `// --- Serialized document (field order == key order)`
  comment is gone; the new module's doc says the opposite and why: *"The structs fix
  the key SET of each object and, through `skip_serializing_if`, which keys are
  omitted; they do NOT fix key ORDER (`serde_json::Map` is a `BTreeMap` here, so
  emitted keys are alphabetical). Determinism therefore comes from the array
  ordering in `sarif.rs`, not from this file."*
- **`tests/cli/sarif_shape_test.rs`**: the run-level tests moved — §7.2.3
  (algorithm-error notification), §7.2.4 (byte determinism), §7.2.5 (allow-list
  rejection + the allow-listed-values positive control), §7.2.10 (degraded parse).
  It carries its own `prism_cmd` / `write_repo` / `fixture_absence` /
  `fixture_degraded` / `run_sarif` / `assert_rule_index_correspondence` copies per
  the repo's CLI-test convention. `tests/cli/sarif_test.rs` keeps the finding-mapping
  tests (§7.2.1, §7.2.2, load warnings, `mod document`) and `fixture_echo`; both
  module doc headers now say which file owns what.
- Registered as `mod sarif_shape_test;` in `tests/cli/main.rs`.

## Important 2 — the untested 4th sort component

Added to `single_algorithm_sarif_shape_and_rule_index` (which owns the §7.2.1
fixture — four pattern families match the same `open(` call, so every result shares
`(uri, startLine, ruleId)` and only `message.text` can order them):

```rust
let messages: Vec<&str> = results.iter().map(|r| r["message"]["text"].as_str().unwrap()).collect();
assert!(messages.len() > 1, "fixture must yield several same-location results ...");
let mut sorted_messages = messages.clone();
sorted_messages.sort_unstable();
assert_eq!(messages, sorted_messages,
    "results sharing (uri, line, ruleId) must be ordered by message.text");
```

**Mutation probe (proof the assertion bites).** Hypothesis: the assertion pins the
4th key. Falsifier: with `message.text` removed from `sort_key`, the test still
passes (which would mean the order is message-sorted for some other reason, e.g.
insertion order). Probe: replaced `result.message.text.as_str()` with `""` in
`sort_key` and re-ran:

```
thread 'sarif_test::single_algorithm_sarif_shape_and_rule_index' panicked at tests/cli/sarif_test.rs:212:5:
assertion `left == right` failed: results sharing (uri, line, ruleId) must be ordered by message.text
  left: ["file open without close ...", "POSIX file descriptor ...", "fs.open without fs.close ...", "Lua file opened ..."]
 right: ["Lua file opened ...", "POSIX file descriptor ...", "file open without close ...", "fs.open without fs.close ..."]
test result: FAILED. 0 passed; 1 failed
```

Result: FAILED as predicted → the assertion discriminates; the alternative
(coincidental ordering) is ruled out because the unmutated emission order is
*not* the insertion order. `sort_key` was restored from a pre-probe copy and
re-verified green.

## Minors

- **(a)** `serde_json::to_value(&log).unwrap_or(Value::Null)` →
  `.expect("SARIF model is always serializable")`, with a comment naming the failure
  mode being rejected (a `null` document printed at exit 0 — a silent failure).
- **(b)** `rule_index.get(..).copied().unwrap_or(0)` →
  `*rule_index.get(..).expect("every result's rule id was registered")`, with a
  comment: `unwrap_or(0)` would silently label a result with *another* rule's index.
- **(c)** `line_zero_omits_the_region` now asserts `physical.get("region").is_none()`
  — the KEY's absence, not a null `startLine`. The same weakness existed in the
  shared `at()` helper (`physical["region"]["startLine"].as_u64()` yields `None` for
  both cases), so `at()` was fixed too: it reads `region` with `.get()` and
  `expect`s a `startLine` when the key exists. That strengthening propagates to the
  three attribution tests, whose region-less related-file entries were previously
  asserted with the same ambiguous probe.
- Two doc claims corrected alongside the `expect`s: `to_sarif`'s "Never fails" and
  the module header's "it has no failure mode" now read "total over its inputs: no
  finding, error or path shape can make it fail" — accurate now that two
  `expect`s exist for states the inputs cannot reach.

## Verification (this round)

```
cargo test --test cli sarif_test::        -> ok.  6 passed; 0 failed
cargo test --test cli sarif_shape_test::  -> ok.  5 passed; 0 failed
cargo test --lib output::sarif            -> ok. 13 passed; 0 failed
cargo test --test cli   (whole target)    -> ok. 154 passed; 0 failed; 0 ignored
cargo fmt --all --check                   -> FMT CLEAN
```

154 = 143 pre-existing CLI tests + the 11 SARIF tests, which are the SAME 11 as
before this round, redistributed 6 / 5 across the two files. Nothing was lost or
duplicated in the split. (Round 1's report quoted 151 for this target because that
run predated the 3-test `mod document` block added later in that round.)

**Clippy delta — 0.** Two probes, as in round 1, because the `-D warnings` run
cannot reach the integration-test targets (the lib's 169 pre-existing errors abort
it — the log shows zero `--> tests/` references):

```
cargo clippy --all-targets --all-features -- -D warnings
  ^error lines: 171  (base 171);  src/output/sarif hits: 0
  diff of sorted/uniq'd ^error headlines vs base -> HEADLINES IDENTICAL

cargo clippy --all-targets --all-features          (reaches every target)
  "--> tests/" references: 82
  src/output/sarif*    warnings: 0
  tests/cli/sarif*     warnings: 0
  src/main.rs          warnings: 3  <- the same three pre-existing needless_borrow
                                       sites established in round 1; main.rs is
                                       untouched by this commit.
```

**Full suite not run this round**, per the coordinator's instruction, on the stated
ground that `src/main.rs` is untouched — verified, not assumed
(`git diff --stat HEAD -- src/main.rs` is empty). The change is confined to
`src/output/**` (a private module split plus two `expect`s) and `tests/cli/**`.
The largest runnable check that was run is the whole `cli` target (154 tests) plus
the lib's `output::sarif*` tests; the lib's other 795 tests and the other 27 test
binaries were **not** re-run in this round and that exclusion is carried into this
done-claim.

## Round-1 concerns now closed / still open

- **Closed:** concern 1 (line-cap headroom) — largest SARIF file is now 476
  (`sarif_rules.rs`, untouched), the four touched files are 448/445/288/171.
- **Closed:** concern 2 (`sarif_rules.rs` outside spec §6) — §6 was amended by
  `1b98e24`/`4be0a36` to permit `sarif_rules.rs`, `sarif_model.rs` and
  `sarif_shape_test.rs`.
- **Still open (unchanged, all pre-existing or informational):** fixture B needing
  `svc.py` in the diff spec; absence emitting four near-duplicate findings for one
  `open(` call; the `preserve_order` note; `properties.related_files` emitted in
  source order while `relatedLocations` file entries are sorted.
