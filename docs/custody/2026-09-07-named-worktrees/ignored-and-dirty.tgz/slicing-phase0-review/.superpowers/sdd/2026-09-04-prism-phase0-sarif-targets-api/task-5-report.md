# Task 5 report — README truth pass, CLAUDE.md / SKILL.md, README gate

Status: **DONE**

Base: branch `phase0-sarif-targets-api`, HEAD before this task `08dc291f99693d21444fe030ce2fe4af8828d056` (Tasks 1-4 complete). Commit for this task: `c8a7dba911f83849c0f4b7ae489e90aae2b0f848` — `docs(phase0): README truth pass, targets + api sections, README gate test (spec §2.5)`.

## Spec-vs-brief deltas (spec wins, disclosed)

1. **`parse_diagram_cap` moves to `src/cli.rs`, not "stays in main.rs".** Design §2.3.3 (written for the Task 3 API-facade extraction) says `determine_exit_code`, `emit_warnings_to_stderr`, `parse_diagram_cap` stay in `main.rs`. That sentence predates the `src/cli.rs` split introduced later in the same design (§2.5.8/§6). Once the clap derive `Cli`/`ReviewArgs` moved into the library crate (`src/cli.rs`, `pub mod cli` in `lib.rs`), `ReviewArgs.diagram_node_cap`'s `value_parser = parse_diagram_cap` attribute requires `parse_diagram_cap` to live in the same crate as the derive (main.rs is a separate, downstream binary crate that cannot be referenced from a `#[derive(Args)]` attribute evaluated inside the library). This is not a style choice; it does not compile otherwise. The task-5 brief anticipated exactly this ("any value-parser helper they reference such as `parse_diagram_cap`"), and I followed the brief/technical necessity over the older §2.3.3 sentence. `determine_exit_code` and `emit_warnings_to_stderr` (which reference no CLI struct) stayed in `main.rs` as §2.3.3 says. `parse_diagram_cap`'s own two unit tests moved with it into `src/cli.rs::tests`; `main.rs`'s `cli_parse_tests` module keeps only the unrelated `run_slicing_inner` compile-time symbol pin.
2. **SKILL.md scope kept narrow.** Design §2.5's items 1-6 and 8 (binding "slicing → prism" rename, deleting the historical-name paragraph) are titled "README truth pass" and apply to `README.md`; the grounding table (`~/code/tools/grounding/readme-truth.md`) is itself scoped to README.md only. Item 7 is the sole authority for SKILL.md, and it names exactly one change: "Output formats" gains `sarif` and a `targets` paragraph. I made only that change and left SKILL.md's own `slicing`-binary framing and CLI examples untouched (they say "the binary is `slicing` (historical name...)" and use `slicing --repo ...` throughout) — both to stay in scope and because the design's own "Explicitly not done" paragraph confirms the clap command's self-identity (`--help`/`--version` header) is still literally "slicing", so the claim is not straightforwardly false. New content I added to SKILL.md matches the file's existing `slicing` convention for internal consistency (see report `Concerns` below).

## Grounding rows applied (row → change)

| Grounding row (readme-truth.md) | Change |
|---|---|
| 84-88 WRONG (binary named `slicing`, rename-planned note) | `README.md` Install section: `target/release/slicing` → `target/release/prism`; deleted the "Note: binary is named `slicing`..." paragraph entirely |
| 80 STALE (`cd slicing`) | `git clone <repo-url> && cd slicing` → `cd prism` |
| ~40 CLI-example rows STALE (`slicing --repo ...`) | Mechanical `^\s*slicing ` → `prism ` across every fenced example (Quick start, per-language sections, Output formats, Piping, CPG Caching, Security Analysis) — verified none remain via `grep -n "slicing" README.md` (only prose uses of the word "slicing" as a technique name survive) |
| 138 STALE ("the six `nav_*` tools") | MCP section: corrected to "eight tools" (six `nav_*` + `taint_reaches` + `refresh_index`), matching CLAUDE.md's existing correct sentence; listed all eight tool names |
| 367-393, 432 STALE (3 of 6/7 formats undocumented) | New "## Output formats" table lists all seven values with one-line descriptions; added "### SARIF and GitHub code scanning" subsection with the `--format sarif > prism.sarif` snippet and a `github/codeql-action/upload-sarif@v3` YAML snippet; Universal-flags `--format` row updated to all seven values |
| 605-606 WRONG (`tests/fixtures/cve/` doesn't exist) | Corrected to the real locations verbatim per the grounding truth column: `tests/fixtures/c/cve_*.c` (+ the two test files that exercise them), `tests/fixtures/sanitizer-suite-{go,js-ts,python}/`, `eval/fixtures/` |
| 603-606 STALE/UNVERIFIABLE (integer underflow, missing-auth claims) | Removed "integer underflows" and "missing authentication checks" (no fixture evidence found by the grounding check); kept only the well-represented classes (buffer overflows, use-after-free/double-free, NULL derefs, command injection) |
| 551 WRONG (`TSTypeProvider`) | Type System table: `TSTypeProvider` → `TypeScriptTypeProvider` (matches `src/type_providers/typescript.rs:122`) |
| 423-436 STALE (Universal flags table incomplete) | Added rows for `--files`, `--scoped-cpg`, `--compile-commands`, `--cache-dir`, `--no-cache`, `--caller-depth`, `--diagram-node-cap`, `--strict-diagrams`, `--review-min-severity`, `--review-full-slices`, `--review-no-diagrams`, and the six `--*-version` flags; added `--taint-return-flow` to the Algorithm-specific flags table next to `--taint-source` |
| 114-141 MISSING (`prism nav` CLI undocumented) | New "### `prism nav` — the same navigation, no MCP client needed" subsection under MCP: two live examples, the ten-subcommand list, and a cross-reference to the two-cache distinction |
| MISSING (framework detection undocumented) | Added a "Framework-aware route detection" bullet to Architecture's "Key design decisions" (11 frameworks named) |
| 561-583 STALE/incomplete (cache scope not distinguished from nav cache) | Added a "Scope — this is one of two, separate caches" paragraph to CPG Caching distinguishing the per-diff CPG cache from `prism nav`'s whole-repo cache under `dirs::cache_dir()/prism/nav/<hash>/` |
| §2.5 item 6 (new sections) | Added "## `prism targets`" (grammar, acceptance table, `--strict` semantics, schema pointer, 3-line JSON excerpt) and "## Library use (`prism::api`)" (compatibility promise quoted verbatim from `src/api/mod.rs`, plus the doc-tested `review()` snippet) between "Piping into other tools" and "Architecture" |
| §2.5 item 7 (CLAUDE.md) | Core Modules list gains `api/`, `targets/`, `finding_confidence.rs`, and expands `output/` to list `sarif.rs`/`sarif_rules.rs`/`sarif_model.rs`; new `cli.rs` entry; `main.rs` entry corrected to describe what it now contains; CLI-usage output-formats comment lists all seven values; new "Finding severity has four values" bullet in Common Patterns; the existing correct "eight tools" MCP sentence (line ~216) left untouched |
| §2.5 item 7 (SKILL.md) | "Output formats" line gains `sarif`; new `prism targets` paragraph with a one-line example |
| §2.5 item 7 (`src/slice.rs:27`) | `pub severity: String, // "info", "warning", or "concern"` → `// "info", "suggestion", "warning", or "concern"` |
| Language count / algorithm count (item 5) | Verified still correct (11 languages/12 grammars; 30 algorithms) — no change needed, these rows were already OK |
| n/a — not addressed | The `eval/` harness "MISSING" row was not given its own section (design item 5's list names "Framework list, nav subcommand list..." but not "eval mention" as a commissioned change); it is now referenced in passing from the corrected CVE-fixtures sentence (`eval/fixtures/`) as the grounding truth column itself specifies, but does not get a dedicated section — consistent with §2.5 items 1-8 not commissioning one |

## The `src/cli.rs` move

Pure move of `Cli`, `ReviewArgs`, `Command`, `NavArgs`, `NavQuery`, `TargetsArgs`, and `parse_diagram_cap` from `src/main.rs` into new `src/cli.rs` (457 lines; under the 600-line cap), `pub mod cli;` added to `src/lib.rs`. Bodies are byte-for-byte identical except: struct/field/enum visibility raised to `pub` (required for `main.rs`, now a separate downstream crate, to construct/match/read them), and `prism::api::DEFAULT_*` → `crate::api::DEFAULT_*` in three `default_value_t` attributes (self-crate-name paths that work from a downstream binary crate do not resolve inside the library crate's own compilation unit — confirmed by a real compile error before the fix, not a style guess). `main.rs` shrank from 1,361 to 921 lines and now imports `prism::cli::{Cli, Command, NavArgs, NavQuery, ReviewArgs, TargetsArgs}`; it keeps `main()`, `run_review`, `run_nav`, `run_targets`, `determine_exit_code`, `emit_warnings_to_stderr`, and all format-dispatch arms.

**`--help`/`--version` proof (captured before any edit):**
```
$ cargo build --release   # HEAD 08dc291, before any Task 5 edit
$ target/release/prism --help > /tmp/help.before
$ target/release/prism --version > /tmp/version.before
```
After the full truth pass + `src/cli.rs` move, rebuilt and re-captured:
```
$ cargo build --release
$ target/release/prism --help > /tmp/help.after2
$ cmp /tmp/help.before /tmp/help.after2   →  HELP IDENTICAL (no output, exit 0)
```
`--version` differs only in the trailing `-dirty` flag (`slicing 3.1.2 (08dc291f9969)` → `slicing 3.1.2 (08dc291f9969-dirty)`): this is `build.rs`'s git-dirty probe correctly detecting the worktree's own uncommitted Task 5 changes at capture time, not a behavioral regression — the version grammar, git SHA, and package version are unchanged. `prism targets --help` and `prism nav --help` were also captured before/after and are byte-identical (`cmp` clean).

## RED evidence (`tests/cli/readme_test.rs` written first, run against the pre-truth-pass README)

```
$ cargo test --test cli readme_test::
running 3 tests
test readme_test::every_readme_prism_invocation_parses ... FAILED
  panicked: "expected many README `prism ...` invocations ...; found 0"
test readme_test::readme_format_list_matches_cli ... FAILED
  panicked: assertion `left == right` failed
    left: {"json", "paper", "text"}
   right: {"callers", "json", "mermaid", "paper", "review", "sarif", "text"}
test readme_test::help_output_contains_every_format_value ... ok
test result: FAILED. 1 passed; 2 failed; 0 ignored
```
`every_readme_prism_invocation_parses` failed because every example still said `slicing …` (no `prism …` lines existed at all — 0 found). `readme_format_list_matches_cli` failed because the README's `--format` row still listed only `text, json, paper` against the CLI's real seven-value allow-list. `help_output_contains_every_format_value` passed even pre-truth-pass because it only compares the compiled binary's own `--help` against its own `Cli::command()` allow-list — it does not depend on README content, so it was never expected to be RED; it is a real, independent assertion of item (c), not a false-positive PASS.

## GREEN evidence

```
$ cargo test --test cli readme_test::
running 3 tests
test readme_test::readme_format_list_matches_cli ... ok
test readme_test::every_readme_prism_invocation_parses ... ok
test readme_test::help_output_contains_every_format_value ... ok
test result: ok. 3 passed; 0 failed; 0 ignored
```
`every_readme_prism_invocation_parses` found 41 `prism …` invocation lines inside fenced blocks, all parsing successfully against `prism::cli::Cli::try_parse_from` (parse-only; a shell-metacharacter truncation handles piped/redirected examples like `prism ... | pbcopy` and `prism ... > out.sarif` — documented in the test as the same "not really CLI argv" exception the design's own `<placeholder>` skip embodies), and skipped 6 quoted lines (e.g. `--barrier-symbols "React.createElement,useEffect"`), asserting that skip path is actually exercised (`skipped_quoted > 0`) rather than silently vacuous.

## Doc-test (`prism::api::review`)

```
$ cargo test --doc api
running 2 tests
test src/api/run.rs - api::run::review (line 352) ... ok
test src/api/mod.rs - api::review (line 23) ... ok
test result: ok. 2 passed; 0 failed
```
The pre-existing doc-test on `run.rs`'s `review()` (from Task 3) only asserted `outcome.inputs.diff.files.len() == 1` and used a Python fixture with no `open()`, so it did not satisfy this task's requirement (temp repo, `a.py` with an unclosed `open()`, the exact JSON diff spec, one finding with `category == Some("missing_counterpart")`). Task 5's permitted-file list restricts my edits to `src/api/mod.rs` (not `run.rs`), so I added a second, independent doc comment + running doctest directly on the `pub use run::review;` re-export line in `mod.rs` (Rust allows a doc comment on a solo re-export to carry its own separate rustdoc entry/doctest, in addition to the one at the original definition — confirmed empirically: `cargo test --doc` now reports 2 distinct doctests, both green, and `--doc` (unfiltered) confirms these are the crate's only two doc-tests). One correction from the initial draft: the fixture's `open("x")` matches **four** absence pattern families (generic/POSIX-fd/`fs.open`/Lua), all sharing category `missing_counterpart` — so the assertion is "at least one finding, and the first one has that category" (`assert!(!findings.is_empty()); assert_eq!(findings[0].category.as_deref(), Some("missing_counterpart"))`), not "exactly one finding", matching the actual runtime behavior (the design's own `sarif_test.rs` documents this same four-pattern-match fixture behavior). The doc-test's visible code (minus the hidden `# Ok::<...>` sentinel) is reproduced verbatim as the README's "Library use" snippet, so the sample the README shows is test-verified on every `cargo test`.

## `cli` test target (whole target, incl. `version_test`)

```
$ cargo test --test cli
test result: ok. 164 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 8.60s
```
Includes `version_test::test_version_includes_git_sha_and_dirty_flag`, `sarif_test::*`, `sarif_shape_test::*`, `targets_test::*`, `validation_test::*` — all green, no regressions from the `cli.rs` move or the `AlgorithmParams`/`review` re-export split.

## `cargo fmt --all`

`cargo fmt --all` ran clean; `cargo fmt --all -- --check` → exit 0.

## Clippy delta

```
$ cargo clippy --all-targets --all-features > /tmp/clippy_task5_full.log 2>&1
$ grep -c "src/cli.rs\|readme_test" /tmp/clippy_task5_full.log
0
$ grep "generated .* warning" /tmp/clippy_task5_full.log | grep "lib test"
warning: `prism` (lib test) generated 169 warnings (129 duplicates) (run `cargo clippy --fix --lib -p prism --tests` to apply 38 suggestions)
```
Zero clippy diagnostics attributable to `src/cli.rs` or `readme_test.rs`; the `lib test` target's aggregate warning count is exactly 169, matching the required baseline. (The `cli` test target's own 2 warnings are pre-existing, in `tests/cli/call_stats_test.rs:647` and `tests/cli/confidence_test.rs:91` — confirmed by line-level grep, not in any Task 5 file.)

## Full suite

```
$ cargo test --all-targets --all-features --no-fail-fast 2>&1 | tee /tmp/phase0-suite-task5.log
$ awk '/^test result:/{p+=$4; f+=$6; i+=$8} END {print "passed="p, "failed="f, "ignored="i}' /tmp/phase0-suite-task5.log
passed=3805 failed=0 ignored=1
```
29 `test result:` lines, all `ok`, zero `FAILED`/`error: test failed` markers (`grep -c "^test result: FAILED"` → 0). Baseline was 3802 passed / 0 failed / 1 ignored; delta is exactly +3, matching the 3 new tests in `readme_test.rs` (the 2 unit tests that moved with `parse_diagram_cap` into `src/cli.rs::tests` are a move, not new tests — net zero; the doc-test is not part of `--all-targets`, which by design excludes doctests, and was verified separately above).

## Byte control

```
$ cargo build --release
$ scripts/phase0-byte-control.sh /Users/wesleyjinks/code/tools/bin/prism-base-c220525 target/release/prism
fixtures (34): ... invocations: 1598 (x2 binaries)
byte control PASSED: 1598/1598 invocations identical (stdout, stderr, exit status)
```
Confirms the `src/cli.rs` move changed no observable behavior across every checked-in fixture diff plus the generated poor-parse fixture, single/multi-algorithm runs, all format arms including `sarif`/`callers`/`mermaid`, an algorithm-error case, and a `--strict-diagrams` invocation.

## Files changed (line counts)

| File | Change |
|---|---|
| `README.md` | +266/-… net (modified in place); 853 lines total |
| `CLAUDE.md` | 15 lines changed; 366 lines total |
| `skills/prism-code-slicing/SKILL.md` | 13 lines changed; 118 lines total |
| `src/api/mod.rs` | +44/-3; 62 lines total (added the `review()` doc-test/re-export) |
| `src/lib.rs` | +1 (`pub mod cli;`) |
| `src/main.rs` | 1,361 → 921 lines (-445 net; clap derive tree moved out) |
| `src/slice.rs` | 1 line changed (severity doc comment) |
| `tests/cli/main.rs` | +1 (`mod readme_test;`) |
| `src/cli.rs` (new) | 457 lines |
| `tests/cli/readme_test.rs` (new) | 174 lines |

`git diff --cached --stat` (pre-commit): `10 files changed, 912 insertions(+), 506 deletions(-)`.

## Self-review

- Verified every `slicing ` CLI-example prefix was replaced (`grep -n "slicing" README.md` after the pass shows only the four legitimate prose uses of "slicing" as a technique name, plus SKILL.md's untouched, out-of-scope examples).
- Verified the GitHub anchor I hand-wrote for the CPG-Caching → `prism nav` cross-reference (`#prism-nav--the-same-navigation-no-mcp-client-needed`) by manually applying GitHub's slug algorithm (strip punctuation incl. backticks/em-dash, lowercase, spaces→hyphens) to the heading text; not gate-tested (no test checks in-README anchors), so this is a manual, unverified-by-tooling check — flagged in Concerns below.
- Confirmed the doc-test's four-pattern-match behavior against the existing `sarif_test.rs` fixture comment before writing the assertion, rather than guessing at "exactly one finding" and getting a spurious RED.
- Confirmed no repo outside `slicing-phase0` was touched, no `.superpowers/` paths were `git add`ed, and no push was performed.

## Concerns

1. **SKILL.md now says two different binary names across the project's docs** (`README.md` says `prism`, `SKILL.md` still says `slicing`), by design-scope decision (see "Spec-vs-brief deltas" above). A user copy-pasting a SKILL.md example (`slicing --repo . --diff ...`) would get "command not found" on a real install, since the actual executable is `prism`. This is pre-existing STALE content that this task's spec explicitly did not commission fixing; flagging it as a real, user-facing gap for a follow-up task rather than silently fixing it (which would have gone beyond this task's permitted-file/scope boundary).
2. **The doc-test lives on the `pub use run::review;` re-export in `mod.rs`, not on the original `review()` definition in `run.rs`.** This works (verified: `cargo test --doc` shows 2 independent green doctests) and stayed within this task's permitted-file list, but it does mean `prism::api::review`'s rendered rustdoc page will show two example blocks (the original file-count check from Task 3, plus this task's finding-assertion one) rather than one unified example. A future cleanup could consolidate them into `run.rs` once that file is back in scope for editing.
3. **`--version`'s `-dirty` suffix in the post-move capture is expected and explained above, not a defect** — noted here only so the reviewer doesn't need to re-derive it: it is solely because the worktree had uncommitted Task 5 changes at the moment of capture, not because the SHA, package version, or version grammar changed.

## Verified / not verified

- Verified: `readme_test` RED→GREEN, `cargo test --doc api`, `cargo test --test cli` (164/164), `cargo fmt --check`, clippy delta (0 in Task 5 files, 169 lib-test baseline preserved), full suite (3805/0/1, +3 over baseline), release build, byte control (1598/1598), `--help`/`--version`/`nav --help`/`targets --help` `cmp`.
- Not verified (out of this task's gate list): Tier-A eval harness (`cd eval && uv run tier-a ...`) — not listed among Task 5's gates in the brief or the orchestrator's gate list, and no source touched by this task falls under Tier-A's normal trigger paths (`call_graph.rs`, `navigation/`, `cpg/`, `ast.rs`); the SARIF/targets Draft-2020-12 schema validation (§8.8) is a design-level, controller-side gate for the whole feature, not scoped to this docs-only task, and was not re-run here.

---

# Fix round 1 — Task 5 review (Opus "Needs fixes": 2 Important + minors)

Status: **DONE**

Base for this round: `c8a7dba911f83849c0f4b7ae489e90aae2b0f848` (this task's original commit) plus an unrelated intervening docs commit `afaf3ebebab5bd5e07e8cc6da6e3676c1edf903b` (`docs/analysis/prism-post-plan-roadmap.md`, one line — no conflict, not touched by this round). Fix commit: **`cd166095cc8a83cf40ef0256a15a1fc0439eb8d4`** — `docs(phase0): SKILL.md binary name, README gate negative assertions, doc-test tempdir (Task 5 review)`.

## Important 1 — SKILL.md's stale `slicing` binary references (controller ruled in-scope)

Replaced every `slicing`-as-binary reference in `skills/prism-code-slicing/SKILL.md` with `prism`, leaving only genuine technique-name prose:
- Front-matter `description` (:3): dropped `` `slicing` `` and the trailing "The binary is named `slicing`." sentence.
- Body sentence (:11, was :11 pre-edit): `` The `slicing` CLI takes `` → `` The `prism` CLI takes ``.
- The "historical name" blockquote (:16-17): the "binary is `slicing` (historical name...)" framing is gone (nothing to claim now that the name matches); kept only the still-true diff-driven/MCP-alternative sentence.
- All 7 CLI-invocation example lines (workflow block, `--list-algorithms` bullet, `--format json | jq` pipe, the two `--review-*` examples, and the `targets --strict` example the review flagged by name) — mechanical `^slicing ` → `prism ` plus the one inline-backtick `` `slicing --list-algorithms` `` → `` `prism --list-algorithms` ``.

`grep -n "slicing" skills/prism-code-slicing/SKILL.md` after the edit shows exactly two survivors, both legitimate: the skill's own `name: prism-code-slicing` and "~30 slicing algorithms" (the technique, not the binary). `prism-code-navigation`'s SKILL.md was not touched (`git status --short skills/` shows only `prism-code-slicing/SKILL.md` modified).

## Important 2 — `readme_test.rs`: negative regression assertion + precise `--help` match

**Negative assertion.** Added `assert_no_stale_slicing_invocations(source_label, text)`, which fails on any fenced line starting with `slicing ` in either README.md or `skills/prism-code-slicing/SKILL.md`, with exactly the specified message shape (verified verbatim below). Wired into `every_readme_prism_invocation_parses` (per the review's explicit naming of that test function) before the existing positive-parse checks, with an explanatory doc comment on *why* this has to be a separate, independent check: a regressed `slicing ...` line simply fails the `prism ` prefix filter used by the positive check and would be silently skipped, never flagged, without this.

**Live-fired proof** (temporary, reverted — not part of the commit): appended a `slicing --repo . --diff x.patch` fenced example to a scratch copy of README.md and re-ran the single test:
```
test readme_test::every_readme_prism_invocation_parses ... FAILED
thread '...' panicked at tests/cli/readme_test.rs:108:9:
README.md regained a `slicing …` example; the binary is `prism` (line: "slicing --repo . --diff x.patch")
```
then restored README.md (`git diff --stat -- README.md` showed no changes afterward) and re-ran to confirm green again. This is real, demonstrated evidence the gate now catches its own regression class, not just code that looks like it would.

**`--help` precision fix (minor 7, folded into Important 2).** Replaced the bare `help.contains(value)` scan (which could pass even if `--format` listed the wrong values, since words like "review" and "json" also appear inside *other* flags' doc comments in the same `--help` text — e.g. `--review-min-severity`, `--caller-depth`) with `help_format_possible_values_line`, which locates the `-f, --format` entry's header line and then finds the very next `[possible values: ...]` line specifically, and matches each CLI value against only that line.

## Minors taken this round

- **(3) Targets JSON excerpt labeled.** README's `prism targets` section now reads "...(JSON Schema Draft 2020-12; `schema_version` is the const `"1.0"`). Excerpt (fields elided — see the schema for the full required-field list per object):" before the 3-field JSON sample, so nobody mistakes it for a complete, schema-valid document.
- **(4) `review()` doc-test uses `tempfile::TempDir`.** Replaced the manual `std::env::temp_dir().join(format!("...{}", std::process::id()))` + explicit `fs::remove_dir_all` pair (which would leak the directory if an assertion panicked before reaching the cleanup line) with `tempfile::TempDir::new()?` (an existing dev-dependency, confirmed usable from a doc-test: `cargo test --doc api` passes with it). `TempDir`'s `Drop` impl removes the directory during unwind, so a failing assertion no longer leaks. The change is in `src/api/mod.rs` (Task 5's permitted file for this doc-test) and the README "Library use" snippet was updated to stay byte-identical to the doc-test's visible code, per the "same snippet in both places" requirement from the original task.
- **(6) `readme_format_list_matches_cli` now checks two independent README lists against the CLI, not one.** Added `readme_output_formats_table_values`, which parses the new seven-row "## Output formats" table's `Flag value` column (scoped strictly to that section — stops at the next heading of *any* level, so it can't bleed into the "### SARIF..." subsection or a later unrelated table), and asserts it equals `cli_format_values()` in addition to the pre-existing Options-reference-row check (renamed `readme_format_values` → `readme_options_table_format_values` for clarity now that there are two).

## Minors explicitly skipped (as instructed)

- **(5) eval harness section** — not added; the coordinator's instruction said skip.
- **(8) `main.rs` pre-existing size** — not addressed; `src/main.rs` is 921 lines post-Task-5 (down from 1,361 after the `cli.rs` move), still above the repo's 600-line convention target but that predates and is out of scope for a docs task; not touched this round per instruction.

## Gate evidence (this round)

```
$ cargo build --all-targets --all-features       → clean (only pre-existing unrelated test warnings)

$ cargo test --test cli readme_test::
running 3 tests
test readme_test::readme_format_list_matches_cli ... ok
test readme_test::every_readme_prism_invocation_parses ... ok
test readme_test::help_output_contains_every_format_value ... ok
test result: ok. 3 passed; 0 failed

$ cargo test --doc
test src/api/run.rs - api::run::review (line 352) ... ok
test src/api/mod.rs - api::review (line 23) ... ok
test result: ok. 2 passed; 0 failed

$ cargo test --test cli
test result: ok. 164 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out

$ cargo fmt --all && cargo fmt --all -- --check   → exit 0

$ cargo clippy --all-targets --all-features > /tmp/clippy_fix1_full.log 2>&1
$ grep -c "src/cli.rs\|readme_test" /tmp/clippy_fix1_full.log
0
$ grep -n "src/api/mod.rs" /tmp/clippy_fix1_full.log
(no output — zero hits)
$ grep "generated .* warning" /tmp/clippy_fix1_full.log | grep "lib test"
warning: `prism` (lib test) generated 169 warnings (129 duplicates) ...

$ cargo test --all-targets --all-features --no-fail-fast 2>&1 | tee /tmp/phase0-suite-task5-fix1.log
$ awk '/^test result:/{p+=$4; f+=$6; i+=$8} END {print "passed="p, "failed="f, "ignored="i}' /tmp/phase0-suite-task5-fix1.log
passed=3805 failed=0 ignored=1
$ grep -c "^test result: FAILED" /tmp/phase0-suite-task5-fix1.log
0
```
Totals unchanged from the prior round (3805/0/1): this round only added assertions inside the three existing `readme_test.rs` test functions, no new `#[test]` functions, so the count is expected to stay flat — confirmed, not a discrepancy.

**Byte control:** skipped this round, as instructed — this round's changes are docs (README.md, SKILL.md) plus test/doc-test code (`tests/cli/readme_test.rs`, a doc comment in `src/api/mod.rs`), none of which touch any code path `scripts/phase0-byte-control.sh` exercises (no `src/main.rs`, `src/cli.rs`, or format-arm change).

## Concerns (this round)

1. The Important-1 fix leaves an intentional, disclosed doc/behavior mismatch: `SKILL.md` now correctly says `prism`, but nothing enforces this going forward the way `readme_test.rs` now enforces it for README.md and SKILL.md's `slicing`-regression case specifically. If SKILL.md ever needs a `slicing`-mentioning example added back for some legitimate future reason, the new negative assertion will (correctly) block it until reworded — this is intended, not a bug, but worth the reviewer knowing the gate is now load-bearing for a second file.
2. Per my original report's Concern 2, `prism::api::review`'s rustdoc page still shows two separate example blocks (one in `run.rs` from Task 3, one here in `mod.rs`) — unchanged this round since `run.rs` remains out of Task 5's permitted-file list.
