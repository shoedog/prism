### Task 3: `prism::api` facade; main.rs becomes its first consumer; same-base control

**Files:**
- Create: `src/api/mod.rs`, `src/api/build_info.rs`, `src/api/review.rs`, `src/api/run.rs`, `src/api/nav.rs`, `scripts/phase0-byte-control.sh`
- Modify: `src/lib.rs` (`pub mod api;`), `src/main.rs` (consume the facade; delete moved helpers), `src/output/mod.rs` only if a re-export is needed
- Create: `tests/integration/api_test.rs`; Modify: `tests/integration/main.rs` (`mod api_test;`)

**Interfaces:**
- Consumes: Task 1/2 re-exports; everything main.rs uses today (`repo_loader`, `cpg_cache`, `CpgContext::*`, `algorithms::*`, `navigation::*`).
- Produces: exactly the surface in spec §2.3.2 v5 (copy the signatures from the spec verbatim — including `ReviewInputs.load_warnings`, `build_context -> Result<BuiltContext<'a>>` with `BuiltContext { ctx, warnings }` carrying the cache-save-failure / type-db-fallback messages main.rs prints today (stderr unchanged), `ReviewOutcome { inputs, run, build_warnings }`, `ReviewRun.results` = successful subsequence with `warnings == parse_warnings` only, `#[derive(Default)] NavOptions`; every struct/enum `#[non_exhaustive]`; `AlgorithmParams` fields = one per `ReviewArgs` algorithm flag: `barrier_depth: usize, barrier_symbols: Vec<String>, chop_source: Option<String>, chop_sink: Option<String>, taint_sources: Vec<String>, taint_return_flow: bool, condition: Option<String>, old_repo: Option<PathBuf>, spiral_max_ring: usize, quantum_var: Option<String>, peer_pattern: Option<String>, layers: Option<String>, concern: Option<String>, temporal_days: usize`). `pub const DEFAULT_BARRIER_DEPTH`, `DEFAULT_SPIRAL_MAX_RING`, `DEFAULT_TEMPORAL_DAYS` in `src/api/run.rs` hold the values currently written as clap defaults in `src/main.rs` for `--barrier-depth`, `--spiral-max-ring`, `--temporal-days` (read them from the source; do not guess), and those clap args switch to `default_value_t = prism::api::DEFAULT_*`.

- [ ] **Step 1: Write the control script first** — `scripts/phase0-byte-control.sh <base-bin> <branch-bin>`:
  - Fixtures: every `*.diff`/`*.patch`/`diff.json` under `tests/fixtures/` with a sibling repo directory (enumerate: `tests/fixtures/python` + `calc.diff`, `tests/fixtures/hapi-4552-source` + `hapi-4552.diff`, `tests/fixtures/nav_compat/*`, `tests/fixtures/review_no_diagrams/*`, `tests/fixtures/c/*` if a diff exists — read each directory's layout and existing tests to pair repo and diff correctly), plus a generated poor-parse fixture written to a temp dir (a Python file whose first 20 lines are `def broken(:` repeated, followed by a valid function that is on the diff).
  - Invocations per fixture: (a) single `--algorithm {leftflow,absence,contract,echo,membrane,provenance,primitive}` × `--format {text,json,paper,review,mermaid}`; (b) `--algorithm echo,absence,contract` and `--algorithm absence,contract,primitive` × `--format {text,json,paper,review,mermaid}`; (c) `--algorithm chop,absence --format json`; (d) `--format callers`; (e) `--algorithm leftflow --format json --strict-diagrams` on `tests/fixtures/diagram_snapshot` if it has a diff (else skip with a printed note).
  - For each invocation run both binaries with identical args and cwd, capture stdout, stderr, exit code to files, `cmp` all three; print `DIFF <invocation>` on any mismatch; exit 1 if any mismatch, else print the count of identical invocations and exit 0.
  - Run it now with `<base-bin> = /Users/wesleyjinks/code/tools/bin/prism-base-c220525` and `<branch-bin>` = a fresh `cargo build --release` of the current HEAD (Task 2 state). Expected: zero diffs (Task 2 changed no existing format). If Task 2 already broke something, STOP and report.
- [ ] **Step 2: Write the failing API tests** `tests/integration/api_test.rs` (§7.3; in-process; fixtures via `tempfile` + `std::fs`; use `prism::api::*`):

```rust
#[test] fn one_shot_review_returns_inputs_and_findings() { /* §7.3.1: one missing_counterpart finding; inputs.diff.files.len()==1; inputs.parse_quality has NO entry for a.py while inputs.files does; a second fixture whose diff also names notes.txt → inputs.load_warnings == ["skipped unsupported file: notes.txt (unsupported language)"] and run.warnings unchanged */ }
#[test] fn two_phase_api_installs_its_own_pool_and_reports_each_algorithm() { /* §7.3.2: no with_build_pool wrapper; let built = build_context(&inputs,&opts)?; run_review(&built.ctx, ...); algorithms_run == ["EchoSlice","AbsenceSlice"]; results[0].algorithm == SlicingAlgorithm::EchoSlice; results[1] == AbsenceSlice; errors empty; warnings == inputs.parse_warnings; built.warnings is empty for this fixture */ }
#[test] fn results_are_the_successful_subsequence() { /* §7.3.2b: run_review(&[Chop, AbsenceSlice]) → algorithms_run == ["Chop","AbsenceSlice"], results.len()==1, results[0].algorithm == AbsenceSlice, errors[0].algorithm == "Chop" */ }
#[test] fn defaults_are_shared_with_clap() { /* §7.3.3: AlgorithmParams::default().barrier_depth == DEFAULT_BARRIER_DEPTH; run `prism --help` via assert_cmd and assert it contains the string format!("[default: {}]", DEFAULT_BARRIER_DEPTH) on the --barrier-depth line */ }
#[test] fn chop_without_params_errors_like_the_cli() { /* §7.3.4 */ }
#[test] fn build_info_is_this_binary() { /* §7.3.5 */ }
#[test] fn nav_session_and_callers_work_without_outer_pool() { /* §7.3.6: let mut o = NavOptions::default(); o.no_cache = true; */ }
#[test] fn api_types_are_non_exhaustive() { /* §7.3.8: read src/api/*.rs and src/finding_confidence.rs; for each line starting with `pub struct`/`pub enum`, the nearest preceding non-blank attribute lines must include `#[non_exhaustive]` */ }
```

- [ ] **Step 3: Run to verify it fails** — `cargo test --test integration api_test::` → compile error (`prism::api` absent). Record.
- [ ] **Step 4: Implement the facade by MOVING code** (spec §2.3.3; doctrine: moves, not copies):
  1. `src/api/build_info.rs`: `BuildInfo` + `build_info()`.
  2. `src/api/review.rs`: `ReviewOptions` (+ `new`), `ReviewInputs`, `load_review_inputs` (cut main.rs `:724-816`: diff read/parse → `DiffInput`, `--files` filter, per-file parse loop with the exact `eprintln!` warnings AND the `load_warnings` vector Task 2 introduced (moved, message formats unchanged), TypeDatabase auto/explicit, `check_parse_quality` (sparse map, unchanged), `scope_graph_build_inputs`; compute `diff_text_sha256` with `sha2`), `build_context` (cut `:819-926` cache decision tree + `:929-960` language versions; the `eprintln!` on cache-save failure stays verbatim).
  3. `src/api/run.rs`: `DEFAULT_*`, `AlgorithmParams` (+ `Default`), `run_algorithm` (cut `:1223-1380` verbatim, replacing `cli.<field>` reads with `params.<field>`; then `annotate_finding_parse_quality(&mut result.findings, &inputs.files)` before `Ok(result)`), `annotate_finding_parse_quality` (cut `:1201-1220`), `parse_file_line` (cut `:1386`, keep private), `parse_algorithms` (cut `:687-704`), `ReviewRun`, `run_review` (the multi-run loop from `:968-997`: per-algorithm `SliceConfig` cloned from `config` with `algorithm` set; errors collected as `AlgorithmError`; `findings` flattened; `warnings = inputs.parse_warnings.clone()`), `ReviewOutcome`, `review` (wraps everything in `build_pool::install`).
  4. `src/api/nav.rs`: `NavOptions`, `nav_session` (cut `build_session` `:610-626`, wrap body in `build_pool::install`), `Seed`, `callers`/`callees` delegating to `navigation::queries::{callers,callees}_with_confidence(s, symbol, file, location, depth, exact_only)` with `Seed::Symbol(s) → (Some(s), None, None)`, `Location(l) → (None, None, Some(l))`, `SymbolInFile{symbol,file} → (Some(symbol), Some(file), None)`.
  5. Wrap `load_review_inputs`, `build_context`, `run_algorithm`, `run_review` bodies in `crate::build_pool::install(|| { ... })`.
  6. `src/api/mod.rs`: module docs = the compatibility promise (spec §2.3.1 verbatim) + re-exports listed in spec §2.3.2.
  7. `src/main.rs`: `run_review` now builds `ReviewOptions`/`AlgorithmParams`/`SliceConfig` from `ReviewArgs`, calls `api::load_review_inputs`, `api::build_context`, keeps the `--format callers` short-circuit, calls `api::run_review` (multi) or `api::run_algorithm` + **`result.warnings = inputs.parse_warnings.clone();`** (single; delete the now-redundant annotate call), keeps every format arm byte-for-byte, and the SARIF arms now read `load_warnings`/`files` from `inputs`. `run_nav` uses `api::nav_session`. Delete the moved private helpers. `main()` still wraps in `build_pool::install` (nesting is safe).
- [ ] **Step 5: Run the tests and the control**

```bash
cargo test --test integration api_test::      # expected: 7 passed
cargo test --test cli                          # expected: unchanged pass count
cargo build --release && scripts/phase0-byte-control.sh /Users/wesleyjinks/code/tools/bin/prism-base-c220525 target/release/prism
```
Expected: control prints zero `DIFF` lines. Any `DIFF` is a defect in the move — fix the move, never the script or the fixtures.

- [ ] **Step 6: Cache-decision control** (§8.6) — for each binary with its own empty temp `--cache-dir`: run 1, run 2, append a comment line to a copy of the fixture's diff-touched file, run 3; record `(cpg-cache.bin exists, mtime changed)` per run; both sequences must read `(created), (unchanged), (changed)`. Put the commands and the observed sequences in the task report.
- [ ] **Step 7: fmt + clippy + full suite + commit**

```bash
cargo fmt --all && cargo clippy --all-targets --all-features -- -D warnings
cargo test --all-targets --all-features --no-fail-fast 2>&1 | tee /tmp/phase0-suite-task3.log; awk '/^test result:/' /tmp/phase0-suite-task3.log
git add src/api src/lib.rs src/main.rs tests/integration/api_test.rs tests/integration/main.rs scripts/phase0-byte-control.sh
git commit -m "feat(phase0): prism::api facade; main.rs consumes it; same-base byte control (spec §2.3)"
```

---

