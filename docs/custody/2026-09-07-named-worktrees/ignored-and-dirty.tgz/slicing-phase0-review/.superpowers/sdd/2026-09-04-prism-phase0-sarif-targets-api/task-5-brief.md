### Task 5: README truth pass, CLAUDE.md / SKILL.md updates, README gate

**Files:**
- Modify: `README.md`, `CLAUDE.md`, `skills/prism-code-slicing/SKILL.md`, `src/slice.rs` (only the `severity` doc comment at `:27`), `src/api/mod.rs` (doc-test snippet if not already present)
- Create: `tests/cli/readme_test.rs`; Modify: `tests/cli/main.rs`
- Read-only input: `/Users/wesleyjinks/code/tools/grounding/readme-truth.md` (row-by-row corrections), spec §2.5

**Interfaces:** consumes Tasks 2–4 CLI surface (`--format sarif`, `prism targets`, `prism::api`); produces nothing code-level beyond the gate test.

- [ ] **Step 1: Write the failing gate** `tests/cli/readme_test.rs`:

```rust
// (a) every line inside ``` fences of README.md that starts with "prism " and contains no '<' is split on whitespace
//     (naive shell split is enough: README examples do not use quotes with spaces — if one does, the test may skip lines containing '"' and say so)
//     and parsed with clap: `prism::cli_command().try_get_matches_from(argv)` where `cli_command()` is a small `pub fn` added to
//     src/main.rs? — main.rs is a bin; instead expose the parse via the binary: run `prism <args...> --help`? No: parsing must not execute.
//     Decision: move the clap `Cli` derive to `src/cli.rs` (pub mod cli in lib.rs) so tests can call `prism::cli::Cli::try_parse_from`.
//     This is a pure move of the derive structs (Cli, ReviewArgs, Command, NavArgs, NavQuery, TargetsArgs); main.rs keeps the run_* fns.
// (b) README's documented format list (the table row `--format` values) == the value_parser array from the Cli definition (compare as sets).
#[test] fn every_readme_prism_invocation_parses() { ... }
#[test] fn readme_format_list_matches_cli() { ... }
```

  Note the design decision embedded above: the clap structs move to `src/cli.rs` (a move, no behaviour change; the byte control re-run proves it). This is an allowed modification (`src/main.rs`) plus one new file `src/cli.rs` — record it in the task report as an addition to spec §6's file list.

- [ ] **Step 2: Run to verify it fails** — `cargo test --test cli readme_test::` (README still says `slicing …` → parse fails; formats list `text, json, paper` ≠ CLI).
- [ ] **Step 3: Apply the truth pass** per spec §2.5 items 1–7 using the grounding table; add the `prism targets` section (acceptance table, schema pointer `docs/contracts/targets.schema.json`, `--strict`), the `Library use (prism::api)` section with the compatibility promise verbatim and this snippet as both README text and a doc-test on `prism::api::review`:

```rust
use prism::api::{review, AlgorithmParams, ReviewOptions};
use prism::slice::{SliceConfig, SlicingAlgorithm};
let outcome = review(&ReviewOptions::new("path/to/repo"), diff_text, &[SlicingAlgorithm::EchoSlice, SlicingAlgorithm::AbsenceSlice],
                     &SliceConfig::default(), &AlgorithmParams::default())?;
for f in &outcome.run.findings { println!("{}:{} {} {}", f.file, f.line, f.algorithm, f.description); }
```
  (the doc-test uses a temp repo built inline so it runs; `no_run` is not acceptable).
- [ ] **Step 4: Run to verify it passes** — `cargo test --test cli readme_test:: && cargo test --doc api`; re-run `scripts/phase0-byte-control.sh`.
- [ ] **Step 5: fmt + clippy + full suite + commit**

```bash
cargo fmt --all && cargo clippy --all-targets --all-features -- -D warnings
cargo test --all-targets --all-features --no-fail-fast 2>&1 | tee /tmp/phase0-suite-task5.log; awk '/^test result:/' /tmp/phase0-suite-task5.log
git add README.md CLAUDE.md skills/prism-code-slicing/SKILL.md src/slice.rs src/cli.rs src/main.rs src/lib.rs src/api/mod.rs tests/cli/readme_test.rs tests/cli/main.rs
git commit -m "docs(phase0): README truth pass, targets + api sections, README gate test (spec §2.5)"
```

---

