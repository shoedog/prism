### Task 1: `finding_confidence` — single-source confidence/tier classification

**Files:**
- Create: `src/finding_confidence.rs`
- Modify: `src/lib.rs` (add `pub mod finding_confidence;` in alphabetical position)
- Test: unit tests inside `src/finding_confidence.rs` (`#[cfg(test)] mod tests`)

**Interfaces:**
- Consumes: `crate::slice::{SliceFinding, SlicingAlgorithm, FileParseQuality}`.
- Produces (used verbatim by Tasks 2 and 4):

```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "lowercase")]
#[non_exhaustive]
pub enum FindingConfidence { Exact, NameOnly, Unlabeled }

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
#[serde(rename_all = "lowercase")]
#[non_exhaustive]
pub enum FindingTier { Asserted, Candidate }

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, serde::Serialize)]
#[serde(rename_all = "lowercase")]
#[non_exhaustive]
pub enum ParseQuality { Clean, Degraded, Poor, Unparseable, Unknown }   // declaration order = best → worst

pub const RESOLUTION_MODE: &str = "nominal";

impl ParseQuality {
    pub fn from_quality_str(q: &str) -> Self;   // "clean"|"degraded"|"poor"|"unparseable" → variant; anything else → Unknown
    /// Worst quality over `files` from the authoritative map; Unknown if `files` is empty or any file is absent.
    pub fn min_over(files: &[&str], map: &std::collections::BTreeMap<String, FileParseQuality>) -> Self;
    pub fn as_str(self) -> &'static str;        // lowercase name
}

/// Anchor file followed by every `related_files` entry (deduplicated, order preserved).
pub fn evidence_files(finding: &SliceFinding) -> Vec<&str>;

pub fn classify(algorithm: &str, parse_quality: ParseQuality) -> (FindingConfidence, FindingTier);
```

- [ ] **Step 1: Write the failing tests** (in `src/finding_confidence.rs`, module `tests`; the module does not compile yet, so the RED observation is "module absent"):

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use crate::slice::{FileParseQuality, SliceFinding};
    use std::collections::BTreeMap;

    fn fpq(q: &str) -> FileParseQuality {
        FileParseQuality { error_count: 0, node_count: 1, error_rate: 0.0, quality: q.to_string(), error_lines: vec![] }
    }
    fn finding(algorithm: &str, file: &str, related: &[&str]) -> SliceFinding {
        SliceFinding {
            algorithm: algorithm.into(), file: file.into(), line: 1, severity: "warning".into(),
            description: String::new(), function_name: None, related_lines: vec![],
            related_files: related.iter().map(|s| s.to_string()).collect(),
            category: None, parse_quality: None, diagrams: vec![],
        }
    }

    #[test] fn ast_only_clean_is_exact_asserted() { assert_eq!(classify("absence", ParseQuality::Clean), (FindingConfidence::Exact, FindingTier::Asserted)); }
    #[test] fn cpg_algorithm_is_unlabeled_candidate() { assert_eq!(classify("echo", ParseQuality::Clean), (FindingConfidence::Unlabeled, FindingTier::Candidate)); }
    #[test] fn degraded_or_unknown_parse_is_candidate() {
        assert_eq!(classify("absence", ParseQuality::Degraded), (FindingConfidence::Exact, FindingTier::Candidate));
        assert_eq!(classify("absence", ParseQuality::Unknown), (FindingConfidence::Exact, FindingTier::Candidate));
    }
    #[test] fn every_production_algorithm_string_parses() {
        for s in ["absence","callback_dispatcher","contract","echo","membrane","peer_consistency","primitive","provenance","symmetry","taint"] {
            assert!(crate::slice::SlicingAlgorithm::from_str(s).is_some(), "{s} must round-trip through from_str");
        }
    }
    #[test] fn unknown_algorithm_is_unlabeled_candidate() { assert_eq!(classify("not_an_algorithm", ParseQuality::Clean), (FindingConfidence::Unlabeled, FindingTier::Candidate)); }
    #[test] fn serde_spellings() {
        assert_eq!(serde_json::to_string(&FindingConfidence::Exact).unwrap(), "\"exact\"");
        assert_eq!(serde_json::to_string(&FindingConfidence::Unlabeled).unwrap(), "\"unlabeled\"");
        assert_eq!(serde_json::to_string(&FindingTier::Candidate).unwrap(), "\"candidate\"");
        assert_eq!(ParseQuality::Poor.as_str(), "poor");
    }
    #[test] fn min_over_takes_the_worst_and_fails_unknown() {
        let mut map = BTreeMap::new();
        map.insert("a.py".to_string(), fpq("clean"));
        map.insert("b.py".to_string(), fpq("degraded"));
        assert_eq!(ParseQuality::min_over(&["a.py"], &map), ParseQuality::Clean);
        assert_eq!(ParseQuality::min_over(&["a.py", "b.py"], &map), ParseQuality::Degraded);
        assert_eq!(ParseQuality::min_over(&["a.py", "missing.py"], &map), ParseQuality::Unknown);
        assert_eq!(ParseQuality::min_over(&[], &map), ParseQuality::Unknown);
        map.insert("c.py".to_string(), fpq("weird"));
        assert_eq!(ParseQuality::min_over(&["c.py"], &map), ParseQuality::Unknown);
    }
    #[test] fn evidence_files_is_anchor_then_related() {
        assert_eq!(evidence_files(&finding("symmetry", "a.py", &["b.py"])), vec!["a.py", "b.py"]);
        assert_eq!(evidence_files(&finding("absence", "a.py", &[])), vec!["a.py"]);
        assert_eq!(evidence_files(&finding("echo", "a.py", &["a.py", "b.py", "b.py"])), vec!["a.py", "b.py"]);
    }
}
```

- [ ] **Step 2: Run to verify it fails**

Run: `cargo test --lib finding_confidence`
Expected: compile error (`finding_confidence` module not found) — record as "feature absent".

- [ ] **Step 3: Implement** `src/finding_confidence.rs` with the module doc from spec §2.1 verbatim (the "Asserted is a claim about the EVIDENCE PATH" paragraph included), the types above, and:
  - `classify`: `match SlicingAlgorithm::from_str(algorithm) { None => (Unlabeled, Candidate), Some(a) => { let conf = if a.needs_cpg() { Unlabeled } else { Exact }; let tier = if conf == Exact && parse_quality == Clean { Asserted } else { Candidate }; (conf, tier) } }`.
  - `min_over`: empty → `Unknown`; fold with `max` over `from_quality_str(&map[f].quality)`, any missing → `Unknown`.
  - `evidence_files`: `finding.file` then each `related_files` entry not already present.
- [ ] **Step 4: Register the module** in `src/lib.rs` (`pub mod finding_confidence;` between `pub mod diff;` and `pub mod framework_entries;`).
- [ ] **Step 5: Run to verify it passes**

Run: `cargo test --lib finding_confidence`
Expected: 8 passed.

- [ ] **Step 6: fmt + clippy + commit**

```bash
cargo fmt --all && cargo clippy --all-targets --all-features -- -D warnings
git add src/finding_confidence.rs src/lib.rs
git commit -m "feat(phase0): finding_confidence — single-source confidence/tier classification (spec §2.1)"
```

---

