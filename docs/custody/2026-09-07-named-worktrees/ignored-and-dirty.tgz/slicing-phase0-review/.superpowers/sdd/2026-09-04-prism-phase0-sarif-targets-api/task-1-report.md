# Task 1 Report: `finding_confidence` — single-source confidence/tier classification

Branch: `phase0-sarif-targets-api`, base HEAD `3471ec5`, commit `a894b3f`.

---

## Fix round 1/5 (spec v4 §2.1 realignment + review minors M1–M5)

Applied on top of `a894b3f`; spec had moved to v4 at `2be06ec` (already on this branch's HEAD when the fix request arrived, ahead of my commit, plus an unrelated docs-only plan commit `42ac24b` from the coordinator's own session — neither touched `src/`, so no conflict). Committed as **`a7cf31e`**.

### Spec v4 delta applied

1. `ParseQuality::min_over` signature changed to take a third parameter, `parsed: &BTreeMap<String, ParsedFile>` (imported `crate::ast::ParsedFile`). Body rewritten for the SPARSE-map semantics: per file, `map.get(file)` → its grade via `from_quality_str`; else `parsed.contains_key(file)` → `Clean`; else `Unknown`. Result is the worst (`max`) over `files`; empty `files` → `Unknown`, unchanged. Doc comment rewritten to explain the sparse-map rationale (mirrors the spec block, with the internal `sol r2 W1` review-tracking tag dropped as not appropriate for shipped code, consistent with how Task 1's original doc comments already handled the analogous `sol #1`/`sol #2` tags).
2. Added `pub fn parse_quality_for(finding: &SliceFinding, map: &BTreeMap<String, FileParseQuality>, parsed: &BTreeMap<String, ParsedFile>) -> ParseQuality`: returns `Unknown` when `finding.category` is one of the four `contract_slice::slice_delta` old-tree categories (`contract_precondition_weakened`, `contract_precondition_strengthened`, `contract_postcondition_weakened`, `contract_postcondition_strengthened`, held in a new private `OLD_TREE_CONTRACT_CATEGORIES` const), else delegates to `min_over(&evidence_files(finding), map, parsed)`. Doc comment mirrors the spec block (again dropping the `sol r2 #2` tag).
3. `ParseQuality` now also derives `serde::Deserialize` (reconciles the spec code block with the brief's Task-1 override, which the review had flagged as a divergence).

### TDD evidence

**RED** — tests updated first to the new interface (3-arg `min_over`, new `parse_quality_for`, revised round-trip/table tests) while the implementation was still the old 2-arg `min_over` with no `parse_quality_for`. `cargo test --lib finding_confidence`:
```
error[E0061]: this function takes 2 arguments but 3 arguments were supplied   (x3, all min_over call sites)
error[E0425]: cannot find function `parse_quality_for` in this scope          (x3, all parse_quality_for call sites)
error: could not compile `prism` (lib test) due to 8 previous errors
```
Exit 101, 8 compile errors — captured to a file and grep-counted (not just tail-viewed) to avoid truncation misreads.

**GREEN** — after implementing `min_over`'s new body/signature and adding `parse_quality_for`, `cargo test --lib finding_confidence`:
```
running 18 tests
... (18 lines, all `... ok`)
test result: ok. 18 passed; 0 failed; 0 ignored; 0 measured; 790 filtered out; finished in 0.20s
```
18 = the original 8 minus the 2 renamed/split (`every_production_algorithm_string_parses` → `..._maps_to_its_variant`; `min_over_takes_the_worst_and_fails_unknown` → split into 5 focused tests) plus the new tests: `confidence_table_for_production_algorithms` (M2), `parse_quality_serde_matches_as_str` (M3), `parse_quality_ordering_is_best_to_worst` (M5), 5 `min_over_*` tests (spec §7.1.7 revised), 3 `parse_quality_for_*` tests (spec §7.1.9 new).

### Tests added/changed (mapped to the fix request)

- **§7.1.7 revised** (`min_over`, sparse-map aware): `min_over_treats_sparse_map_absence_as_clean_when_parsed`, `min_over_takes_the_worst_over_files`, `min_over_is_unknown_for_files_in_neither_map_nor_parsed`, `min_over_empty_files_is_unknown`, `min_over_unrecognized_map_quality_string_is_unknown`. A shared `parsed_with(path)` test helper builds a real `ParsedFile::parse(path, "x = 1\n", Language::Python).unwrap()` entry, per the fix request's instruction to use a real parse rather than a stub.
- **§7.1.9 new** (`parse_quality_for`): `parse_quality_for_treats_contract_delta_categories_as_unknown` (a `contract_precondition_weakened` finding on a clean-parsed file → `Unknown`), `parse_quality_for_non_delta_contract_category_uses_min_over` (a `contract_violation` finding on the same file → `Clean`), `parse_quality_for_symmetry_related_file_dominates` (a symmetry finding whose `related_files[0]` is degraded → `Degraded`).
- **Review M1**: `every_production_algorithm_string_maps_to_its_variant` now asserts `SlicingAlgorithm::from_str(s) == Some(expected_variant)` for all ten production strings, not just `is_some()`.
- **Review M2**: `confidence_table_for_production_algorithms` — table-driven, asserts `classify(s, Clean).0` for all ten strings against the expected `FindingConfidence` (absence/contract/symmetry/primitive/peer_consistency/callback_dispatcher → `Exact`; echo/membrane/provenance/taint → `Unlabeled`), matching `needs_cpg()` in `src/slice.rs`.
- **Review M3**: `parse_quality_serde_matches_as_str` — for all five `ParseQuality` variants, `serde_json::to_string(&q).unwrap().trim_matches('"') == q.as_str()`.
- **Review M5**: `parse_quality_ordering_is_best_to_worst` — `Clean < Degraded < Poor < Unparseable < Unknown`, chained as one `assert!`.

### fmt / clippy / full lib suite

- `cargo fmt --all` applied; `cargo fmt --all -- --check` exits 0.
- `cargo clippy --all-targets --all-features -- -D warnings`: still exits 101 with 171 pre-existing errors (same count and, verified by `diff` on the sorted `error:` lines, the *exact same set* as the Task-1-baseline clippy log) — zero new clippy findings introduced by this round, and none in `src/finding_confidence.rs`.
- `cargo test --lib finding_confidence`: 18 passed, 0 failed.
- `cargo test --lib` (full suite): **808 passed, 0 failed, 0 ignored** (up from 798 pre-fix — net +10 tests, matching 18 new/changed `finding_confidence` tests minus 8 originals... i.e. 10 net-new test functions after renames/splits). No `FAILED` lines in the log.

### Files changed

- `src/finding_confidence.rs` only (179 insertions, 32 deletions; file now 421 lines, still under the 600-line ceiling — no split into `src/finding_confidence/tests.rs` was needed).
- `src/lib.rs` untouched this round (no new module registration required).

### Self-review

- `min_over` and `parse_quality_for` signatures are byte-for-byte what the fix request specifies.
- `parse_quality_for`'s old-tree category list matches the four strings confirmed present in `src/algorithms/contract_slice.rs` (`contract_precondition_weakened`, `contract_precondition_strengthened`, `contract_postcondition_weakened`, `contract_postcondition_strengthened`), and does not misfire on the fifth contract category, `contract_violation`, which is exercised by a test to confirm it falls through to `min_over`.
- `ParseQuality` derive list now includes `Deserialize`, closing the spec/brief divergence the review flagged in round 0.
- Only `src/finding_confidence.rs` touched; no new crate dependencies (`crate::ast::ParsedFile` and `crate::languages::Language` were both already crate-internal, used only inside the test module for `Language`).
- No functionality beyond the fix request was added — did not touch `classify`'s signature or logic (unchanged, still correct against the unchanged rules), did not add a `classify_with_evidence` (still explicitly out of scope per the module doc).

### Concerns

None blocking, unchanged from round 0: the pre-existing 171-error clippy debt on this branch remains pre-existing and out of this task's scope (re-verified identical before/after this round). No new concerns introduced by this fix round.

## What was implemented

New module `src/finding_confidence.rs`, registered as `pub mod finding_confidence;` in `src/lib.rs` (alphabetically between `diff` and `framework_entries`, as specified). It is the single source both the SARIF and `targets` serializers will consult for a finding's confidence/tier label:

- `FindingConfidence { Exact, NameOnly, Unlabeled }` — `#[non_exhaustive]`, `serde(rename_all = "lowercase")`.
- `FindingTier { Asserted, Candidate }` — `#[non_exhaustive]`, `serde(rename_all = "lowercase")`.
- `ParseQuality { Clean, Degraded, Poor, Unparseable, Unknown }` — `#[non_exhaustive]`, `PartialOrd`/`Ord` derived from declaration order (best → worst), `Serialize` only (per the brief's authoritative derive list — no `Deserialize`), `serde(rename_all = "lowercase")`.
- `RESOLUTION_MODE: &str = "nominal"`.
- `ParseQuality::from_quality_str`, `ParseQuality::min_over`, `ParseQuality::as_str`.
- `evidence_files(finding: &SliceFinding) -> Vec<&str>` — anchor file then deduplicated `related_files`, order preserved.
- `classify(algorithm: &str, parse_quality: ParseQuality) -> (FindingConfidence, FindingTier)` — implements exactly the brief's pseudocode: unknown algorithm string → `(Unlabeled, Candidate)`; `needs_cpg()` → confidence `Unlabeled`, else `Exact`; tier `Asserted` iff confidence is `Exact` and parse quality is `Clean`, else `Candidate`.

The module doc comment (lines 1–13) is copied verbatim from design spec §2.1, including the "Asserted is a claim about the EVIDENCE PATH" paragraph.

`classify` never produces `NameOnly` (reserved for a later item, per the rules) and never touches the CPG — it is pure and total over its two inputs.

## TDD evidence

**RED** — `cargo test --lib finding_confidence` (file written with only the `#[cfg(test)] mod tests` block, *not yet* registered in `src/lib.rs`, so the module is absent from the compiled crate — the brief's prescribed "feature absent" observation):
```
running 0 tests
test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 790 filtered out; finished in 0.00s
```
0 of the 8 target tests ran (module not compiled in) — confirms the feature did not exist yet.

**GREEN** — after implementing the module and adding `pub mod finding_confidence;` to `src/lib.rs`, `cargo test --lib finding_confidence`:
```
running 8 tests
test finding_confidence::tests::ast_only_clean_is_exact_asserted ... ok
test finding_confidence::tests::unknown_algorithm_is_unlabeled_candidate ... ok
test finding_confidence::tests::cpg_algorithm_is_unlabeled_candidate ... ok
test finding_confidence::tests::degraded_or_unknown_parse_is_candidate ... ok
test finding_confidence::tests::every_production_algorithm_string_parses ... ok
test finding_confidence::tests::serde_spellings ... ok
test finding_confidence::tests::evidence_files_is_anchor_then_related ... ok
test finding_confidence::tests::min_over_takes_the_worst_and_fails_unknown ... ok

test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 790 filtered out; finished in 0.00s
```
Matches the brief's expected "8 passed" exactly, no test text changed from the brief.

## Files changed

- `src/finding_confidence.rs` (new, 274 lines — under the 600-line ceiling)
- `src/lib.rs` (+1 line: `pub mod finding_confidence;`)

No other files touched; no new crate dependencies added (only `serde` and `std::collections::BTreeMap`, both already crate dependencies).

## fmt / clippy / full lib suite

- `cargo fmt --all` — applied (reformatted the test module's compact one-line `#[test] fn ...` bodies onto multiple lines; no semantic change). `cargo fmt --all -- --check` afterwards exits 0.
- `cargo clippy --all-targets --all-features -- -D warnings` — exits 101 (171 `error:` diagnostics), but **zero** of them are in `src/finding_confidence.rs` or the changed line of `src/lib.rs` (verified: `grep -n finding_confidence` on the clippy log matches nothing).
  - **Attribution control performed**: stashed the task's changes (`git stash -u`), ran the identical clippy command against base commit `3471ec5`, and got the same 171 `error:` diagnostics (verified via `diff` — the only differences between the two logs are dependency-compilation progress lines from a cold vs. warm build cache; the error content is byte-identical). Restored the stash (`git stash pop`) before committing. This confirms the clippy failures are 100% pre-existing on the base commit and not introduced by this task.
  - Pre-existing warning locations (file: finding count), not touched per the task's constraint (no edits outside `src/finding_confidence.rs` and `src/lib.rs`):
    `src/mcp/transport_tests.rs`(32), `src/ast.rs`(18), `src/call_graph.rs`(16), `src/resolution.rs`(15), `src/algorithms/taint.rs`(10), `src/type_providers/go.rs`(6), `src/algorithms/quantum_slice.rs`(6), `src/algorithms/absence_slice.rs`(6), `src/live_types.rs`(5), `src/cpg/cfg_queries.rs`(4), `src/cpg/build.rs`(4), `src/type_providers/python.rs`(3), `src/cpg/query.rs`(3), `src/algorithms/horizontal_slice.rs`(3), `src/algorithms/contract_slice.rs`(3), `src/algorithms/angle_slice.rs`(3), and 1–2 each in `src/type_provider.rs`, `src/terraform.rs`, `src/repo_loader.rs`, `src/reasoning/sanitizer_walk.rs`, `src/mcp/evidence_view.rs`, `src/cpg_cache.rs`, `src/algorithms/provenance_slice.rs`, `src/algorithms/primitive_slice.rs`, `src/type_providers/java.rs`, `src/type_db.rs`, `src/slice.rs`, `src/resolution_receiver/tests.rs`, `src/output/mermaid.rs`, `src/navigation/seed.rs`, `src/navigation/queries.rs`, `src/navigation/call_edge_cache.rs`, `src/mcp/transport.rs`, `src/mcp/tools.rs`, `src/mcp/session.rs`, `src/mcp/output.rs`, `src/languages/mod.rs`, `src/go_type_alias/canon.rs`, `src/go_receiver_index_visibility.rs`, `src/go_receiver_index.rs`, `src/diff.rs`, `src/data_flow.rs`, `src/cpg/types.rs`, `src/cpg/tests.rs`, `src/cfg.rs`, and one each in several `src/algorithms/*.rs` files (vertical_slice, symmetry_slice, spiral_slice, resonance_slice, peer_consistency_slice, gradient_slice, delta_slice, chop). Lint kinds observed: `needless_borrow`, `unnecessary_lazy_evaluations`, `for_kv_map`, `map_or` simplifications, collapsible `if`, identical-block `if`, manual `Iterator::find`, loop-counter suggestions, derivable `impl`, manual prefix-stripping, doc-list indentation, elidable lifetimes, too-many-arguments, `assertions_on_constants`, and more — a broad, pre-existing lint debt unrelated to this task.
- `cargo test --lib` (full lib suite, per the task's instruction to scope to lib tests since this task touches nothing else): `798 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out`. No `FAILED` or compiler-error lines in the log.

## Self-review

- Module doc comment matches spec §2.1 verbatim, including the "Asserted is a claim about the EVIDENCE PATH" paragraph.
- All three public enums (`FindingConfidence`, `FindingTier`, `ParseQuality`) carry `#[non_exhaustive]`.
- `ParseQuality` derives exactly the brief's authoritative list (`Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize`, no `Deserialize`) — this differs from the spec doc's literal code block (which shows no serde derives on `ParseQuality` at all), but the task instructions explicitly say the brief's derive list overrides the spec here; followed the brief.
- Function/type signatures are byte-for-byte what the brief specifies.
- `classify`'s logic matches the brief's pseudocode exactly: unknown algorithm string → `(Unlabeled, Candidate)`; `needs_cpg()` → `Unlabeled` else `Exact`; tier `Asserted` iff `Exact` and `Clean`.
- `min_over`: empty → `Unknown`; any missing file → `Unknown`; otherwise the max (worst) of `from_quality_str` over present files — matches the declaration-order-derived `Ord` so "worst" is well-defined.
- `evidence_files`: anchor file first, then `related_files` entries not already present — dedupes correctly (verified against the `["a.py","b.py","b.py"]` → `["a.py","b.py"]` test case).
- No functionality beyond what the brief/spec asked for was added — no `classify_with_evidence`, no `NameOnly` production path (both explicitly reserved for a later item per spec's module doc, and neither is used anywhere in this file).
- Doc comments on individual items (not required verbatim by the task, only the module-level doc was required verbatim) closely follow the spec's inline comments/doc lines where available (`RESOLUTION_MODE`, `min_over`, `evidence_files`), with the internal review-tracking annotations (`sol #1`, `sol #2`) dropped as not appropriate for shipped code.
- Diff scope confirmed via `git diff --stat` / `git show --stat`: only `src/finding_confidence.rs` (new) and `src/lib.rs` (+1 line) — no edits outside the permitted files.
- File is 274 lines, well under the 600-line ceiling.

## Concerns

None blocking. Two items worth flagging to the controller for awareness, not action:

1. The pre-existing clippy debt (171 errors across ~50 files) means `cargo clippy --all-targets --all-features -- -D warnings` does not exit 0 on this branch overall, even though this task's own code is clippy-clean. If a later task's DoD checks clippy's exit code rather than diff-scoped clippy output, that will surface as a pre-existing failure unrelated to any of the five phase-0 tasks — worth deciding whether that lint debt gets addressed in this branch or tracked separately before merge.
2. `ParseQuality`'s derive list per the brief (`Serialize`, no `Deserialize`, with `rename_all = "lowercase"`) intentionally diverges from the design spec's literal code block (which shows plain `Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord` with no serde attributes at all). This is called out in the task's own Context section as brief-overrides-spec, so implemented per the brief; flagging only so the spec document itself gets reconciled to match if that hasn't already happened elsewhere in the SDD trail.
