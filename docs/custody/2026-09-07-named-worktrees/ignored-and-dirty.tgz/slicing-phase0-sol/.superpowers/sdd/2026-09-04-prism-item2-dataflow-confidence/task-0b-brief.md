### Task 0b: CFG statement-universe completeness — **designated behaviour commit**

> This is item 2's **only** commit permitted to change pinned bytes (§5 / owner E4). It is isolated: no refactor, no RD, no perf work, no cache bump. Its permitted-file amendment is stated in Global Constraints and applies to this task only.

**Why.** REPORT.md §H measures the fraction of existing DataFlow edges whose **use** line is in the CFG line universe and whose **def** line is in that universe or is the function start: **Rust 32.9 %, TSX 22.5 %, Go 47.9 %, Python 77.1 %, bash 38.2 %, javascript 45.2 %, typescript 46.4 %, C 57.8 %, C++ 64.1 %.** Spec §4.2 step 33 sends every non-admissible edge to `NameOnly(CfgIncomplete)` **before any cap is consulted**. Without this task, item 2 ships a mechanism that is ~2/3 inert on Rust and ~3/4 inert on TSX, which lesson 16 (`docs/superpowers/pipeline-lessons.md:187-193`) calls a presumed-broken mechanism. The fixture packs cannot surface this: every pack with any DFG edges scores **90.5–100 %**.

**The verified Rust mechanism** (REPORT.md §G, re-read at `bffb847`): `collect_statements` (`src/ast.rs:5805-5824`) pushes a child when `is_statement_node(kind)` and then recurses into its body **only if `is_control_flow_node(kind)`** (`:5816`). tree-sitter-rust wraps a block-tailed `if`/`match`/`loop` used as a statement in an `expression_statement`, which **is** a statement node (`src/languages/mod.rs:800-807`) but is **not** a control-flow node (`:576-610`) — so the walk records the header line and stops, and the entire body is invisible. Probe source is saved as `~/code/tools/logs/item2-census/probe-rust-cfg-coverage.rs`.

**Files:**

- Modify: `src/ast.rs` — `collect_statements` (`:5805`), `collect_statement_spans` (`:5826`), `collect_nested_statements` (`:5849`) only.
- Modify: `src/languages/mod.rs` — a new per-language wrapper-unwrap table only. Do not change `is_statement_node` (`:800`), `is_control_flow_node` (`:576`), `is_scope_block` (`:781`) or `is_declaration_node` (`:238`) semantics; add a table beside them.
- Test: `src/ast.rs` in-module tests; `src/cfg.rs` in-module tests.
- Re-bless in this same commit: whichever `tests/fixtures/**/golden` and structural expectations move (`tests/fixtures/nav_compat/golden`, `tests/fixtures/review_no_diagrams/golden` are the only checked-in goldens at `bffb847`).

**Interfaces:**

- Consumes: `Language::is_statement_node` (`src/languages/mod.rs:800`), `Language::is_control_flow_node` (`:576`), tree-sitter node kinds.
- Produces:

```rust
/// Kinds that WRAP a statement without being one semantically. When
/// `collect_statements` meets one it must descend through it, or the wrapped
/// body's lines never enter the CFG's line universe
/// (`ParsedFile::statements_in_function`). Measured: this is why Rust scores
/// 14.1% line coverage and 32.9% DataFlow-edge admissibility
/// (logs/item2-census/REPORT.md §G, §H).
pub fn statement_wrapper_kinds(&self) -> &'static [&'static str];
```

- `statements_in_function` keeps its signature `(&self, &Node) -> Vec<(usize, String)>` and its sort/dedup contract (`src/ast.rs:5788-5790`). It returns **more** lines than before. That is the behaviour change.

**Steps:**

- [ ] **Step 1: Write one RED probe per language, measured — not assumed.** REPORT.md §G measured the mechanism for **Rust only**; the other languages have measured *coverage* but not a measured *cause*. For each of Rust, TSX, TypeScript, JavaScript, Go, Python, C, C++, Java, Bash, Lua: dump the statement universe of a minimal function with a nested statement and record what is missing before proposing any fix. Reuse the census instrument's dump path:

```bash
cd /Users/wesleyjinks/code/slicing-item2
DFG_CENSUS_DUMP_STMTS=1 cargo run --release --example dfg_census -- <probe-dir> 2>&1 | tee /tmp/item2-stmt-probe-<lang>.log
```

Write down, per language, the expected observation if "wrapper kind blocks recursion" is true and what would falsify it. Record which you got. A language whose probe shows full coverage needs **no** change — do not edit it.

- [ ] **Step 2: Write the failing Rust unit test** in `src/ast.rs`'s test module:

```rust
#[test]
fn statements_in_function_descends_through_expression_statement_wrappers() {
    // tree-sitter-rust wraps a block-tailed `if` used as a statement in an
    // `expression_statement`, which is a statement node but not a control-flow
    // node — so `collect_statements` recorded line 3 and stopped, hiding 4 and 5.
    let source = "fn h(x: i32) {\n    let a = x + 1;\n    if a > 0 {\n        let c = a + 1;\n        g(c);\n    }\n    g(a);\n}\n";
    let parsed = ParsedFile::parse("m.rs", source, Language::Rust).unwrap();
    let func = parsed.functions().first().unwrap().node;
    let lines: Vec<usize> = parsed
        .statements_in_function(&func)
        .into_iter()
        .map(|(l, _)| l)
        .collect();
    assert!(lines.contains(&4), "if-body `let c` (line 4) must be a CFG statement line, got {lines:?}");
    assert!(lines.contains(&5), "if-body `g(c)` (line 5) must be a CFG statement line, got {lines:?}");
    assert!(lines.contains(&2) && lines.contains(&3) && lines.contains(&7), "pre-existing lines must survive: {lines:?}");
}
```

Add the analogous test for each language whose Step-1 probe showed a gap, using that language's own wrapper kind.

- [ ] **Step 3: Run RED.**

Run: `cargo test --lib ast::tests::statements_in_function_descends`
Expected: FAIL — `lines` is `[2, 3, 7]`; 4 and 5 are absent.

- [ ] **Step 4: Implement the minimal unwrap.** Add `statement_wrapper_kinds` to `src/languages/mod.rs` (Rust: `["expression_statement"]`; other languages only as their Step-1 probe justified) and consume it in `collect_statements` / `collect_statement_spans`:

```rust
if self.language.is_statement_node(kind) {
    out.push((line, kind.to_string()));
    if self.language.is_control_flow_node(kind) {
        self.collect_nested_statements(child, out);
    } else if self.language.statement_wrapper_kinds().contains(&kind) {
        // The wrapper's own line is already recorded above; descend so the
        // wrapped body's lines enter the CFG universe too.
        self.collect_nested_statements(child, out);
    }
}
```

Do not widen `is_statement_node` or `is_control_flow_node`: widening `is_control_flow_node` would also change `build_branch_edges` and the C switch-fallthrough behaviour that `test_c_switch_fallthrough` pins (`src/cfg.rs:797+`).

- [ ] **Step 5: Run GREEN on the unit layer.**

Run: `cargo test --lib ast::` and `cargo test --lib cfg::`
Expected: the new tests PASS and every pre-existing `cfg`/`ast` test still PASSes. A pre-existing CFG test that now fails is a real regression — fix the change, do not edit the test.

- [ ] **Step 6: Acceptance (i) — re-measure CFG admissibility at CORPUS level (sol r1 W2).**

The fixture packs already score **90.5–100 %** before any change (REPORT.md §1, §H), so a fixture-pack threshold is green before the work and proves nothing. The metric is **corpus-level, per §7.1 language, over the same Tier-A anchor corpora the census measured** — rerun with the identical command list from REPORT.md §5 so before and after are comparable:

```bash
cd /Users/wesleyjinks/code/slicing-item2 && cargo build --release
cargo run --release --example dfg_census -- --corpora ~/code/tools/logs/item2-census/corpora \
  2>&1 | tee ~/code/tools/logs/item2-census/after-0b.log
```

Produce this table in the task report — `after` is `Σ n_dfg_edges_cfg_ok / Σ n_dfg_edges` per language, corpus rows only, fixture packs excluded from the metric:

| §7.1 language | before (REPORT.md §H) | DFG edges measured | after | verdict |
|---|---:|---:|---:|---|
| rust | 32.9 % | 247,716 | _fill_ | ≥90 pass / [75,90) attributed / <75 STOP |
| go | 47.9 % | 1,312,976 | _fill_ | ″ |
| python | 77.1 % | 209,388 | _fill_ | ″ |
| typescript | 46.4 % | 2,330 | _fill_ | ″ |
| javascript | 45.2 % | 301 | _fill_ | ″ |
| *(tsx, reported alongside ts)* | 22.5 % | 4,396 | _fill_ | ″ |

**Pass rule, exactly:**
- **≥ 90 %** — pass.
- **[75 %, 90 %)** — **not a pass by default.** Two conditions must both hold before the controller rules at all: the task report attributes **≥ 95 % of that language's remaining non-admissible edges to named mechanisms**, each with a standalone probe in the style of REPORT.md §G (a minimal source, the dumped statement universe, and the tree-sitter node kind that blocked the walk); and the percentage is reported beside its function and edge counts. Then the controller records one of two rulings, and **only one of them passes** (sol r2 S1; spec v6.2 §10):
  - **`ACCEPT`** — recorded with a reason. This, and only this, is a pass.
  - **`SECOND PASS`** — extend the wrapper fix to cover the named mechanisms, **re-run Step 6's census, and re-apply this whole rule** to the new numbers before Step 7. A recorded `SECOND PASS` is *not* a pass; proceeding to Step 7 on one is a plan violation. Recording *a ruling* is the reporting obligation; recording `ACCEPT` is the pass condition, and v3 conflated the two.

  An unattributed residual is not eligible for either ruling — fix the attribution first.
- **< 75 %** — **STOP.** Report the residual mechanisms and escalate; do not raise the number by widening a predicate the Step-1 probe did not justify.

**Population caveat, stated so the [75,90) ruling has its denominator in view:** the eleven anchor corpora are 3 Rust + 5 Go + 3 Python. The JS/TS/TSX edges come from vendored files inside prometheus (387 tsx / 302 ts functions), ruff (223 tsx / 34 ts) and prism (2 tsx / 40 ts) — **javascript's whole corpus population is 36 functions / 301 edges**. Report the per-language function and edge counts next to the percentage; a corpus percentage over a three-figure edge population is a weak signal and the controller should rule on it as such rather than treating it as equivalent to Rust's 247k.

- [ ] **Step 7: Acceptance (ii) — Tier-A, the behaviour gate.**

```bash
cd /Users/wesleyjinks/code/slicing-item2 && cargo build --release
cd eval && uv run tier-a --matrix-only --allow-stale-sut
cd eval && uv run tier-a --quick --allow-stale-sut
```

Run the identical pair on `~/code/tools/bin/prism-base-bffb847` in the same environment. Expected: **no recall loss and precision at or above base.** A recall loss is a STOP; do not rebaseline `docs/eval/tier-a/*.json`.

- [ ] **Step 8: Acceptance (iii) — re-bless goldens in this commit.** Run the byte control to enumerate what moved:

```bash
scripts/phase0-byte-control.sh ~/code/tools/bin/prism-base-bffb847 target/release/prism 2>&1 | tee /tmp/item2-0b-bytes.log
```

Expected: a **non-empty, enumerated** set of differing invocations (this is the behaviour commit). For each, review the diff and record in the task report *why* the new bytes are correct (a statement line that was invisible is now in the CFG universe). Re-bless the affected goldens in this same commit. An invocation whose diff you cannot explain by the statement-universe change is a STOP.

- [ ] **Step 9: Acceptance (iv) — re-base the control, again from the detached worktree (sol r1 W4).** Commit Task 0b first (Step 12), then rebuild the control from `/Users/wesleyjinks/code/slicing-phase0-review` checked out at the Task 0b commit. Never check out paths inside the item 2 worktree, and no `|| true`:

```bash
set -e
cd /Users/wesleyjinks/code/slicing-item2
TASK0B=$(git rev-parse HEAD)
cd /Users/wesleyjinks/code/slicing-phase0-review
git fetch ../slicing-item2 "$TASK0B"          # the worktrees share the object store; fetch is a no-op if so
git checkout --detach "$TASK0B"
test -z "$(git status --porcelain)"
cargo build --release
cp target/release/prism ~/code/tools/bin/prism-item2-0b
shasum -a 256 ~/code/tools/bin/prism-item2-0b | tee -a ~/code/tools/logs/item2-custody.txt
git checkout --detach bffb847                  # leave the review worktree where Task 0 found it
```

**From here on `~/code/tools/bin/prism-item2-0b` is the byte-control base for Tasks 1–7**, and those tasks must be zero-diff against it. `~/code/tools/bin/prism-base-bffb847` is retained as the control for Tasks 0 and 0b only, and as the reference for the Task 0b diff review in the handoff.

- [ ] **Step 10: Acceptance (v) — no cache transition here.**

```bash
rg -n 'CACHE_VERSION' src/cpg_cache.rs   # still 55 at this point
rg -n 'NAV_CALL_EDGE_CACHE_VERSION' src/navigation/call_edge_cache.rs   # 24
```

The 55→56 bump belongs to Task 1 and happens exactly once.

- [ ] **Step 11: Full suite + gates.** `cargo test --all-targets --all-features --no-fail-fast` against the Task 0 baseline totals; `cargo fmt --all -- --check`; clippy delta.

- [ ] **Step 12: Commit — isolated.**

```bash
git add src/ast.rs src/languages/mod.rs tests/fixtures
git commit -m "feat(item2): descend through statement wrappers in the CFG universe" \
  -m "Designated behaviour commit (spec §5, owner E4): Tier-A no recall loss, goldens re-blessed in this commit, no cache transition." \
  -m "Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>" \
  -m "Claude-Session: https://claude.ai/code/session_015U8HwBTAFzFzqJbbq82JBT"
```

---

