# Task 2 phase 1 — reaching-definitions signature proposal

Status: proposal only; no tests or implementation have been written.

## Exact declarations proposed for approval

```rust
use crate::access_path::AccessPath;
use crate::ast::ParsedFile;
use crate::cpg::FlowConfidence;
use crate::data_flow::{FlowEdge, VarLocation};
use std::collections::{BTreeMap, BTreeSet};
use tree_sitter::Node;

/// Hard caps from the authorised measurement pass
/// (~/code/tools/logs/item2-census/REPORT.md §2.3, 92,338 functions).
/// RD_MAX_LINES bounds `stmt_lines.len()` — the CFG statement-line universe
/// returned by `ParsedFile::statements_in_function` — NOT the function's line
/// span (`end - start + 1`). Measured worst case: 590 defs, 331 statement
/// lines; 0 of 92,338 functions exceed either cap.
pub(crate) const RD_MAX_DEFS: usize = 2048;
pub(crate) const RD_MAX_LINES: usize = 4096;

pub(crate) type Line = usize;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub(crate) struct DefId(pub(crate) u32);

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct DefSite {
    pub(crate) id: DefId,
    pub(crate) path: AccessPath,
    pub(crate) line: Line,
    pub(crate) start_byte: usize,
    pub(crate) alias_derived: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum RdUnavailable {
    DefinitionsCapExceeded { actual: usize },
    StatementLinesCapExceeded { actual: usize },
    NoCfgEdges,
}

impl RdUnavailable {
    pub(crate) fn is_def_cap(self) -> bool {
        matches!(self, Self::DefinitionsCapExceeded { .. })
    }

    pub(crate) fn is_line_cap(self) -> bool {
        matches!(self, Self::StatementLinesCapExceeded { .. })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum RdOutcome {
    Available(RdResult),
    Unavailable(RdUnavailable),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct RdResult {
    pub(crate) labels: BTreeMap<(VarLocation, VarLocation), FlowConfidence>,
    pub(crate) loop_carried_edges: BTreeSet<(VarLocation, VarLocation)>,
}

#[derive(
    Debug, Clone, Copy, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize,
)]
pub struct RdFileStats {
    pub functions_over_cap: usize,
    pub functions_without_cfg: usize,
}

pub(crate) fn reaching_definitions(
    parsed: &ParsedFile,
    func_node: &Node<'_>,
    defs: &[DefSite],
    dfg_edges: &[FlowEdge],
) -> RdOutcome;
```

## Pseudocode mapping and rationale

- `Line = usize` preserves the repository's one-based source-line convention and is the key domain for §4.2 lines 1, 4, and 9–28.
- `DefId(u32)` gives every Def occurrence a dense bit position for the fixed-width GEN/KILL and IN/OUT vectors in lines 8–28; `u32` is sufficient under `RD_MAX_DEFS = 2048`.
- `DefSite` carries the occurrence identity, structured path, source line, and byte anchor used by lines 10–19 and to match line 29's DFG source endpoint; `alias_derived` materializes the existing DFG alias-resolution decision for lines 14–15 and 35.
- `RdUnavailable` realizes lines 2–3 and the line-33 no-CFG case with three observable reasons; the two cap variants carry the measured input count so assertion failures identify which bound fired and by how much.
- `RdOutcome` makes availability explicit before line 33 can assign `CfgIncomplete`, while keeping successful per-edge results separate from a reason that Task 3 must count.
- `RdResult.labels` is the line 29–38 output on Task 3's exact key shape; `loop_carried_edges` records the strict subset identified at line 37 so Task 3 can increment loop telemetry without re-running the proof.
- `RdFileStats` is the per-file accumulator implied by line 3 and the no-CFG branch of line 33; Task 3 increments `functions_over_cap` for either cap variant and `functions_without_cfg` only for `NoCfgEdges`.
- `reaching_definitions` takes one parsed function, its occurrence-granular Defs, and only that function's existing DFG edges; it builds and restricts CFG state per lines 1–28 and labels without adding or removing an edge per lines 29–38.

`alias_map` and the unused `alias_stable` pseudocode input are deliberately not accepted by the entry point. The caller that already executes `DataFlowGraph::build_alias_map` / `resolve_path` marks each generated twin with `DefSite::alias_derived`; repeating alias resolution inside RD would create a second consult, while v6.4 lines 14–15 and 35 require every such edge to remain non-killing and `AliasUnstable` regardless of stability.

For `RdOutcome::Unavailable`, Task 3 uses the supplied `dfg_edges` slice to emit `NameOnly(CfgIncomplete)` for every existing edge and updates `RdFileStats` from the reason. `RdResult.labels` therefore exists only for `Available`, matching the conservative stub and RED shape in the brief.

## Spec ambiguities requiring the controller's ruling

1. Section 4.2 line 2 combines both caps in one condition and does not define the observable reason when both are exceeded. This proposal checks `defs.len()` first, then `stmt_lines.len()`, so a function over both reports `DefinitionsCapExceeded`; the required decoupled tests remain independent of that priority.
2. Section 4.2 line 29 assumes access to `dfg.edges` although the INPUT block does not pass an edge collection. This proposal makes the per-function `dfg_edges: &[FlowEdge]` input explicit because the required result is keyed by the existing endpoints and the pass may not create or remove edges.
3. Section 4.2 lists `alias_stable`, but v6.4 lines 14–15, line 35, and §4.3 make stability irrelevant: every alias-derived edge is `AliasUnstable` and alias relations never prove KILL. This proposal omits both alias collections and accepts the already-materialized `DefSite::alias_derived` bit.
