1. Dual-cap precedence: check `defs.len() > RD_MAX_DEFS` FIRST, then `stmt_lines.len() > RD_MAX_LINES`; a function over both reports `DefinitionsCapExceeded`. Deterministic and cap-specific is all that matters; the §7.2 fixtures are decoupled so each fires alone.
2. `dfg_edges: &[FlowEdge]` as an explicit per-function input is APPROVED (the pseudocode's `dfg.edges` was implicit). Labels are produced ONLY for keys present in that slice; never add or remove an edge (§3 non-goal 1).
3. Omitting `alias_map` / `alias_stable` is APPROVED: `DefSite.alias_derived` marks alias twins, every edge whose def or use is alias-derived is `NameOnly(AliasUnstable)`, and alias relations never prove a KILL (spec v6.4 §4.2 steps 14–15/35, §4.3).

# Task 2 report — reaching-definitions core pass

## Custody

- Starting HEAD: `53b0dbd1857b3c0fcbdffb36ed9516cd71133060`
- Branch: `item2-dataflow-confidence`
- Starting `git status --short`: empty
- Workspace: `/Users/wesleyjinks/code/slicing-phase0-sol`
- Pushes/sub-agents: none

## RED evidence

- Feature absence: after registering `mod reaching;` and before creating the
  module, `cargo test --lib cpg::reaching::tests` failed with rustc `E0583`,
  `file not found for module reaching` at `src/cpg.rs:29`. The first tee pipeline
  did not preserve Cargo's status and was treated as inadmissible; the corrected
  `set -o pipefail` run exited 101. Log:
  `target/item2-controls/task2-red-feature-absence.log`.
- Conservative stub: the approved declarations and all 25 tests compiled, then
  **1 passed / 24 failed / 0 ignored**. The sole passing test was
  `zero_cfg_edge_function_returns_unavailable_for_the_no_cfg_reason`; every
  label assertion received `Unavailable(NoCfgEdges)`, both cap fixtures observed
  the wrong reason, and the long-span and exact-cap poles observed Unavailable.
  There were no fixture setup failures. Log:
  `target/item2-controls/task2-red-stub.log`.

## Implementation

- Added the approved per-function entry point and types in
  `src/cpg/reaching.rs`; `RdFileStats` is public, serde-enabled, and re-exported
  from `cpg`, while the rest of the unwired pass remains crate-private.
- Enforced the definition cap before the statement-line cap, then built the
  function CFG from `build_cfg_edges_with_arms` with a synthetic ENTRY for
  parameter definitions. The analysis uses fixed-width bit vectors and a
  reverse-postorder worklist with predecessor union, including loop back edges.
- Built GEN/KILL by occurrence while excluding alias-derived relations from
  kill proofs. Same-line groups use only `(AccessPath, line)` and never byte
  ordering.
- Mapped every DFG endpoint line through the innermost containing statement
  span. Unmapped endpoints, nested-callable captures, try/defer/lexical-arm
  safety joins, and unavailable functions fail closed as `CfgIncomplete`.
- Produced labels only for the supplied `dfg_edges` keys, with the binding
  precedence `CfgIncomplete` > `SameLine` > `AliasUnstable` > `Killed`, and
  recorded the exact loop-carried subset separately for Task 3 telemetry.
- Kept the production module at 558 lines. Its 672-line test module is split
  into `src/cpg/reaching/tests.rs`; no production file other than `src/cpg.rs`
  was modified.
- Tests-first commit: `3ef0c4b6dd781a6670f349236f7ba65ac34c4359`.
- Implementation commit: `5b56c35fc35a1afcc9eccb20463aee914411e2a9`.

## Verification

- Focused GREEN: `cargo test --lib cpg::reaching::tests` — **32 passed, 0
  failed, 0 ignored**. This covers GEN/KILL, diamond union, loop-carried flow,
  lowest reachable `kill_line`, unreachable kills, all three distinct
  availability reasons, decoupled cap fixtures, exact-cap poles, long spans,
  innermost/continuation/unmapped statement mapping, exact label-key retention,
  serde stats, same-line collapse, alias instability, all required capture
  constructs, immediate Go defer arguments, and all three CFG safety joins.
- Full suite: `cargo test --all-targets --all-features --no-fail-fast` exited 0.
  The requested awk aggregation found **3,875 passed, 0 failed, 1 ignored over
  30 result lines**: the 3,843-test base plus 32 RD tests.
- Doctests: `cargo test --doc --all-features` — **2 passed, 0 failed, 0
  ignored**.
- Formatting: `cargo fmt --all -- --check` exited 0.
- Clippy: the literal `cargo clippy --lib --all-features -- -D warnings`
  reports 130 pre-existing errors on both the exact `53b0dbd` base and the
  candidate. Normalized error headings/source locations are byte-identical;
  regular clippy exits 0 with 130 warnings (3 duplicates) and 127 source
  warning lines on each side. **Clippy delta: zero.** No warning originates in
  `src/cpg/reaching.rs`.
- Release build: `cargo build --release` exited 0 immediately before the
  accuracy harness.
- Tier-A matrix: `uv run tier-a --matrix-only --allow-stale-sut` — **104/104
  cases OK**.
- Byte control:
  `scripts/item2-byte-control.sh /Users/wesleyjinks/code/tools/bin/prism-item2-0b target/release/prism`
  — **272/272 invocations identical** in stdout, stderr, and exit status.
- Review cap: two rounds as declared. Round 1's exception-bypass hypothesis
  was refuted by a focused regression test; round 2 verified that the normal
  try-body edge is sequential while only structured try exception/finally
  joins are marked incomplete. No demonstrated correctness defect remained.
- Final `git status --short` before staging contained only the three intended
  source paths. Generated Tier-A report/snapshot files were explicitly removed
  and neither `.superpowers/` nor `target/` is staged.
- Post-commit `git status --short --untracked-files=all` is empty.

## Concerns

- The prescribed Tier-A quick run produced a result artifact but exited 2 as
  invalid. Its matrix was entirely OK and SUT error rate was 0, but adding the
  new module changed the seeded C-name sample; rust-analyzer timed out for both
  directions of unchanged `src/mcp/transport.rs:878 new`, leaving 4/6 successful
  probes and oracle error rate 0.0667. An exact-base, same-environment control
  had zero oracle/SUT errors and was invalid only because base SHA `53b0dbd`
  differs from the pinned corpus `20c8490`. The generated quick artifacts were
  inspected and removed rather than committed or used to re-baseline.
- The pass is intentionally unwired. Task 3 must construct the approved dense
  `DefId` sequence, apply `Unavailable` labels to the supplied edges, and
  persist `RdFileStats`.
