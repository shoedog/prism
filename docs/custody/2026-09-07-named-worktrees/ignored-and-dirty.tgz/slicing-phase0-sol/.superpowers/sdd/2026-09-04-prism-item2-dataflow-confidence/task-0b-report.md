# Task 0b report — CFG statement-universe completeness

## Historical Step-6 STOP outcome (superseded by Resume below)

**BLOCKED at the binding Step-6 corpus gate.** The wrapper change improved every
measured language except JavaScript's unchanged 301-edge population, but Rust,
Go, JavaScript, TypeScript, and TSX remain below the 75% STOP floor. Python is in
the middle band but has no eligible controller ruling because this report does
not attribute at least 95% of its 40,209 remaining non-admissible edges. Per the
brief, work stopped before Tier-A, byte control, golden re-blessing, clippy,
control-binary custody, or commit. A later verification hook explicitly required
the after full suite and root `VERIFICATION.md`; that test-only exception is
recorded below and did not resume the stopped acceptance sequence.

## Custody

- Starting HEAD: `9fbdd92`
- Branch: `item2-dataflow-confidence`
- Starting `git status --short`: empty
- Workspace: `/Users/wesleyjinks/code/slicing-phase0-sol`
- Pushes/sub-agents: none
- Cache versions observed after the change: CPG `55`, nav call-edge `24`

## Baseline tests

`cargo test --all-targets --all-features --no-fail-fast` completed before edits:
30 `test result:` lines, **3816 passed / 0 failed / 1 ignored**. `cargo test
--doc` completed with **2 passed / 0 failed / 0 ignored**. Logs:

- `target/item2-controls/suite-before.log`
- `target/item2-controls/doc-before.log`

## RED evidence and mechanism probes

The first RED command was inadmissible because the test helper used a nonexistent
`FunctionInfo::node` field. It was corrected to the existing `all_functions()`
node path and rerun before production code changed. The admissible run executed
11 tests and failed **0 passed / 11 failed**. Verbatim assertion payloads from
`target/item2-controls/red-statement-wrappers.log`:

| Language | Missing nested statement evidence on 9fbdd92 |
|---|---|
| Rust | `[("sink_rust_if", 4), ("sink_rust_match", 7), ("sink_rust_loop", 10), ("sink_rust_while", 14), ("sink_rust_for", 18)]; got [2, 3, 6, 9, 13, 17, 20, 21, 22, 23, 24, 25]` |
| Python | `[("sink_py_with", 3), ("sink_py_case", 6), ("sink_py_except(x)", 10), ("sink_py_finally", 12), ("sink_py_except_group", 16)]; got [4, 7, 8, 13, 14, 17]` |
| JavaScript | `[("sink_js_label", 5), ("sink_js_case", 10), ("sink_js_default", 13), ("sink_js_catch", 18), ("sink_js_finally", 20), ("sink_js_with", 23)]; got [2, 3, 8, 15, 16, 25]` |
| TypeScript | `[("sink_ts_label", 5), ("sink_ts_case", 10), ("sink_ts_default", 13), ("sink_ts_catch", 18), ("sink_ts_finally", 20)]; got [2, 3, 8, 15, 16, 22]` |
| TSX | same missing set and universe as TypeScript |
| Go | `[("sink_go_label", 6), ("sink_go_select(v)", 11), ("sink_go_select_default", 13), ("sink_go_switch(y)", 17), ("sink_go_switch_default", 19), ("sink_go_type(v)", 23), ("sink_go_type_default", 25)]; got [3, 4, 9, 27]` |
| C | `[("sink_c_label", 5), ("sink_c_attribute", 9)]; got [2, 3, 12]` |
| C++ | `[("sink_cpp_label", 5), ("sink_cpp_attribute", 9), ("sink_cpp_catch", 15)]; got [2, 3, 12, 13, 17]` |
| Java | `[("sink_java_sync", 5), ("sink_java_case", 9), ("sink_java_default", 12), ("sink_java_rule(y)", 15), ("sink_java_rule_default", 16), ("sink_java_try", 19), ("sink_java_catch", 21), ("sink_java_finally", 23)]; got [3, 25]` |
| Bash | `[("sink_bash_do", 4), ("sink_bash_case", 7), ("sink_bash_subshell", 10), ("sink_bash_redirect", 13)]; got [2, 3, 6, 9, 12]` |
| Lua | `[("sink_lua_middle", 5), ("sink_lua_last", 7)]; got [2, 3, 9]` |

The census dump and zero-error syntax trees are under
`target/item2-controls/census-0b/`. The pre-change observations confirmed these
blocking node shapes:

- Rust: `expression_statement` around `if_expression`, `match_expression`,
  `loop_expression`, `while_expression`, and `for_expression`; additional
  `unsafe_block`, `async_block`, `const_block`, `try_block`, and `gen_block`
  wrappers were independently dumped.
- Python: `with_statement`, `case_clause`, `except_clause`,
  `except_group_clause`, and `finally_clause`.
- JavaScript/TypeScript/TSX: `labeled_statement`, `switch_case`,
  `switch_default`, `catch_clause`, and `finally_clause`; JavaScript also
  measured `with_statement`.
- Go: `labeled_statement`, `select_statement` with `communication_case` /
  `default_case`, `expression_switch_statement` with `expression_case`, and
  `type_switch_statement` with `type_case`.
- C/C++: `labeled_statement` and `attributed_statement`; C++ also measured
  `catch_clause`.
- Java: `synchronized_statement`, `switch_expression` / `switch_block` with
  classic `switch_block_statement_group` and arrow `switch_rule`, plus
  `try_with_resources_statement`, `catch_clause`, and `finally_clause`.
- Bash: `do_group`, `case_item`, `subshell`, and `redirected_statement`.
- Lua: `elseif_statement` and `else_statement`.

Two initial written expectations misnumbered Go and C++ lines. Those observations
were treated as inadmissible; corrected expectations were recorded before the
rerun in `probes/CORRECTED-HYPOTHESES.md`.

## Implemented wrapper table

`Language::is_statement_node` and `Language::is_control_flow_node` semantics were
not changed.

| Language | `statement_wrapper_kinds()` |
|---|---|
| Rust | `expression_statement`, `async_block`, `const_block`, `gen_block`, `try_block`, `unsafe_block`, `while_expression` |
| Python | `with_statement`, `except_clause`, `except_group_clause`, `finally_clause`, `case_clause` |
| JavaScript | `labeled_statement`, `catch_clause`, `finally_clause`, `switch_case`, `switch_default`, `with_statement` |
| TypeScript / TSX | `labeled_statement`, `catch_clause`, `finally_clause`, `switch_case`, `switch_default` |
| Go | `labeled_statement`, `select_statement`, `communication_case`, `default_case`, `expression_switch_statement`, `expression_case`, `type_switch_statement`, `type_case` |
| C | `labeled_statement`, `attributed_statement` |
| C++ | `labeled_statement`, `attributed_statement`, `catch_clause` |
| Java | `labeled_statement`, `synchronized_statement`, `switch_expression`, `switch_block`, `switch_block_statement_group`, `switch_rule`, `try_with_resources_statement`, `catch_clause`, `finally_clause` |
| Bash | `do_group`, `case_item`, `subshell`, `redirected_statement` |
| Lua | `elseif_statement`, `else_statement` |
| Terraform | empty |

The line, byte-span, and arm-map walkers were changed child-for-child. The
pre-existing double descent in `collect_nested_statements` and its twins was not
removed or given another recursive call; the same shape now recognizes wrapper
children. A non-recursive direct-statement branch was added for wrappers such as
Bash `subshell` whose child is a `command`, not a block.

Focused GREEN:

- `cargo test --lib ast::`: **35 passed / 0 failed**
- `cargo test --lib cfg::`: **20 passed / 0 failed**
- The inherited Python/TypeScript negative tripwire failed exactly when Python
  line 10 entered the universe, then was flipped to positive body and multi-arm
  assertions. `arm_map_covers_every_cfg_statement_line` is green.
- `cargo fmt --all -- --check`: clean before the corpus STOP.
- After the STOP, the verification hook tightened the language fixture helper to
  assert statement-span parity and arm totality, made Rust block-wrapper markers
  non-vacuous, added Java label coverage, and added switch-fallthrough and
  mandatory-finally arm edge cases. Focused results were 11 + 1 + 1 passed.
- Hook-required final full suite: **3829 passed / 0 failed / 1 ignored** across
  30 `test result:` lines; final doc-tests: **2 passed / 0 failed / 0 ignored**.

## Corpus admissibility — binding Step 6

The release census was run exactly once per specified Tier-A anchor tree with
`DFG_CENSUS_SKIP_CPG=1`; no repository was cloned or updated. Raw CSVs and
summaries are in `target/item2-controls/census-0b/`, with the combined run in
`corpora-after.log` and aggregate in `aggregate-after.txt`.

The historical BEFORE population is REPORT.md §G/§H as required. AFTER is the
sum of the 14 current anchor CSVs. Function-count drift is visible because the
required BEFORE is the older report population while AFTER is the current
9fbdd92 branch plus Task-0b tests; edge denominators changed only slightly for
Rust (+224), Go (+10), Python (+19), and TypeScript (+1), and remained 301 for
JavaScript and 4,396 for TSX.

| Language | Before (functions / DFG edges / admissible) | After (functions / DFG edges / CFG-ok / admissible) | Rule outcome |
|---|---:|---:|---|
| Rust | 34,445 / 247,716 / 32.9% | 34,555 / 247,940 / 151,363 / **61.05%** | **STOP** (<75%) |
| Go | 26,803 / 1,312,976 / 47.9% | 26,867 / 1,312,986 / 936,827 / **71.35%** | **STOP** (<75%) |
| Python | 27,780 / 209,388 / 77.1% | 27,841 / 209,407 / 169,198 / **80.80%** | **MIDDLE-BAND**, no `ACCEPT` eligibility |
| JavaScript | 36 / 301 / 45.2% | 45 / 301 / 136 / **45.18%** | **STOP** (<75%); three-figure denominator |
| TypeScript | 336 / 2,330 / 46.4% | 376 / 2,331 / 1,542 / **66.15%** | **STOP** (<75%) |
| TSX (reported with TS) | 612 / 4,396 / 22.5% | 612 / 4,396 / 1,193 / **27.14%** | **STOP** (<75%) |
| Bash (informational; not §7.1) | 179 / 1,017 / 38.2% | 179 / 1,017 / 872 / **85.74%** | middle band if threshold applied |
| C (informational; not §7.1) | 1,581 / 39,466 / 57.8% | 1,581 / 39,466 / 23,668 / **59.97%** | below 75% if threshold applied |
| C++ (informational; not §7.1) | 559 / 4,914 / 64.1% | 559 / 4,914 / 3,276 / **66.67%** | below 75% if threshold applied |

The supplied task text also calls TypeScript `25.5%`; REPORT.md §G identifies
25.5% as TypeScript **line coverage**, while REPORT.md §H and the binding Step-6
table identify **46.4%** as edge admissibility. This report uses 46.4% for the
edge comparison. The supplied Java 76.1% has no denominator or row in REPORT.md
§H, and none of the 14 specified anchor trees produced a Java row after the
change. Lua likewise had no anchor-corpus row. No Java/Lua corpus percentage is
invented.

## Residual mechanisms and probes

The hard STOP means these are diagnoses, not authorization to widen the Task-0b
change:

1. **Multiline expression endpoints.** The CFG universe records the enclosing
   statement's start line, while the DFG can place a parameter use on a later
   continuation line. The standalone six-language residual probe shows only
   lines `[2,4,8]` (language-specific equivalents) in `STMTS`; its continuation
   line is absent with zero parse errors.
2. **Nested anonymous-callable ownership.** The DFG charges edges inside a
   closure/function literal/arrow body to the enclosing named function, while
   the CFG walk stops at the containing `let`/short declaration/lexical
   declaration. The probe syntax trees show `closure_expression`, `func_literal`,
   and `arrow_function` bodies under those statements. Outer-function probe
   results were Rust 3/4, Go 5/7, Python 2/3, JavaScript 3/4, TypeScript 2/3, and
   TSX 2/3 admissible edges.

Probe artifacts:

- `target/item2-controls/census-0b/residual-probes/`
- `target/item2-controls/census-0b/residual-after.log`
- `target/item2-controls/census-0b/residual-after.csv`
- `target/item2-controls/census-0b/residual-ast-after.log`

The largest real residual rows also show that the failure is not a probe-only
edge case: Go generated gateway handlers have 22,440 and 19,805 non-admissible
edges; Rust's `evaluate_known_cases` has 2,076; JavaScript's `setupTermynal` has
73/73 non-admissible; TypeScript's `autocompleteMetricName` has 98/98; and TSX's
`Playground` has 203/209. CSV rows alone do not distinguish mechanisms, so no
unsupported percentage attribution is claimed. In particular, Python's two
named mechanisms are **not** claimed to explain at least 95% of its 40,209-edge
residual.

## Gates not run after STOP

- Byte control: **not run**; differing invocation population unavailable.
- Golden re-blessing/diff review: **not run**; no goldens changed.
- Tier-A base/head matrix and quick LSP oracle: **not run**.
- After full suite and doc-tests: **run only because the later verification hook
  required them**; 3829 / 0 / 1 plus 2 / 0 / 0 doc-tests.
- Clippy base/head delta: **not run**.
- Post-commit release control copy and SHA-256: **not created**.
- Commit: **none**.

These remaining omissions are required by the Step-6 sequencing and `<75% =>
STOP` instruction, not silent skips.

## Deviations and concerns

- No implementation file outside `src/ast.rs`, `src/cfg.rs`, and
  `src/languages/mod.rs` was changed. The report itself is under `.superpowers/`
  as requested and is not eligible for staging. The later hook additionally
  required root `VERIFICATION.md`; it is not an implementation file and no
  commit was made.
- The change is left uncommitted because five gated language results violate the
  hard floor. It must not become the branch's designated behaviour commit without
  an amended design/controller direction.
- Meeting the current threshold appears to require work beyond wrapper unwrapping
  (DFG function ownership and/or multiline endpoint modeling), both outside this
  task's permitted surface. That conclusion is a mechanism-level hypothesis,
  not a quantified 95% attribution.

## Resume — v6.3 span-admissibility ruling

The controller ruled that the raw start-line gate conflated wrapper gaps,
continuation-line endpoints, and nested-callable ownership. The authoritative
v6.3 spec makes statement-span admissibility the Task-0b gate and excludes edges
touching nested callable bodies from its denominator. Under that corrected
metric, every §7.1 language passes outright; the historical STOP above remains
as the audit trail and is no longer the current outcome.

### Census RED/GREEN and method

`examples/dfg_census.rs` now preserves `n_dfg_edges_cfg_ok` and adds
`n_dfg_edges_span_ok` plus `n_dfg_edges_nested_callable` per function. Span
membership maps each `StatementSpan` from its start line through the inclusive
line containing its end byte. Nested-callable membership uses DFG endpoint byte
spans against AST callable-body byte ranges, so an unrelated endpoint sharing a
line with a lambda is not excluded.

The first compile attempt retained one stale `edge_lines` field and was
inadmissible. With a compiling zero stub, the semantic RED executed all three
tests and failed **0 passed / 3 failed**:

- continuation line: `assertion left == right failed`, `left: 0`, `right: 1`
- lambda: `an edge touching the lambda body must be excluded`
- the initial same-line JS fixture also failed its population guard; it was
  corrected to use distinct parameter paths before it was accepted as an edge
  case.

GREEN is **3 passed / 0 failed**. The continuation-line edge is span-ok but not
raw CFG-start-ok; the Python lambda edge is nested-callable; and the JS edge case
puts nested and unrelated outer uses on the same line and proves only a strict
subset is excluded. Logs: `target/item2-controls/census-span-{red,green}.log`.

### Resume measurement and pass rule

The release census ran exactly once per each of the same 14 anchor trees with
`DFG_CENSUS_SKIP_CPG=1`. All 14 CSVs and 14 summaries under
`target/item2-controls/census-0b-span/` reconcile: row counts equal
`functions_named`, row edge sums equal `dfg_edges_total`, and unjoined DFG keys
are zero. The run-log `tee` opened before the first process created its output
directory and failed, but all primary outputs completed; they were validated and
no tree was rerun.

| Language | REPORT §H raw before (functions / edges) | Raw start-line after | Span-admissible after (numerator / eligible denominator) | Nested-callable edges | Outcome |
|---|---:|---:|---:|---:|---|
| Rust | 32.9% (34,445 / 247,716) | 61.04% (151,421 / 248,069) | **95.33%** (215,619 / 226,176) | 21,893 | **PASS** |
| Go | 47.9% (26,803 / 1,312,976) | 71.35% (936,827 / 1,312,986) | **98.82%** (1,005,793 / 1,017,828) | 295,158 | **PASS** |
| Python | 77.1% (27,780 / 209,388) | 80.80% (169,198 / 209,407) | **97.64%** (199,131 / 203,945) | 5,462 | **PASS** |
| JavaScript | 45.2% (36 / 301) | 45.18% (136 / 301) | **98.05%** (151 / 154) | 147 | **PASS** (301 total / 154 eligible edges) |
| TypeScript | 46.4% (336 / 2,330) | 66.15% (1,542 / 2,331) | **98.10%** (1,704 / 1,737) | 594 | **PASS** |
| TSX | 22.5% (612 / 4,396) | 27.14% (1,193 / 4,396) | **99.35%** (2,460 / 2,476) | 1,920 | **PASS** |
| C (information) | 57.8% (1,581 / 39,466) | 59.97% (23,668 / 39,466) | **85.34%** (26,007 / 30,475) | 8,991 | non-gating middle band |
| Java (information) | supplied as 76.1%, no §H denominator | N/A (0 / 0) | N/A (0 / 0) | 0 | no anchor population |

No §7.1 language is in the middle band, so residual attribution and an `ACCEPT`
ruling are unnecessary. Current named-function counts are Rust 34,570; Go
26,867; Python 27,841; JavaScript 45; TypeScript 376; TSX 612; C 1,581; Java 0.

### Resumed acceptance gates

- Byte control: **1,598 / 1,598 invocations identical** for stdout, stderr, and
  exit status. Differing invocation population: zero.
- Golden reviews: neither `tests/fixtures/nav_compat/golden` nor
  `tests/fixtures/review_no_diagrams/golden` changed; no re-blessing was needed.
- Tier-A matrix: base 104 / 104 `ok`; head 104 / 104 `ok`; no regressions.
- Tier-A quick: the first base attempt was invalid only for corpus pin drift
  (`9fbdd92` vs `20c8490`). Valid same-environment base/head runs used
  `--allow-drift`; both have `baseline_invalid=false`, zero oracle/SUT error,
  identical m1/m2/m3/matrix/pending/site-fingerprint payloads, and all 108
  precision/recall points identical (minimum recall and precision deltas 0.0).
- Full suite after the census extension: **3,832 passed / 0 failed / 1 ignored**
  over all 30 result lines. Doc-tests: **2 passed / 0 failed / 0 ignored**.
- Clippy: exact base/head warning delta zero (239 instances / 76 messages on
  both sides; no head-only or base-only warning). Both commands exit 0.
- `cargo fmt --all -- --check` and `git diff --check`: clean.
- Isolated commit:
  `0b51138aa6fe88267643610cd0b132b116a87935` (`0b51138`). Required trailers
  are present verbatim.
- Post-commit control binary: `target/item2-controls/prism-item2-0b`, reporting
  `slicing 3.1.2 (0b51138aa6fe)`. SHA-256:
  `897840b5d5222dc463bd5ff883ebd476dbd0fde43f752882e5e6e8761343c9ae`.

### Shape, deviations, and concerns

The three walkers and the Task-0 arm mirror remain child-for-child. The
pre-existing double descent in `collect_nested_statements` and its mirrored
span/arm walkers was not removed, expanded, or given another recursive call;
only the wrapper membership condition changed. No RD, predicate-semantics,
threshold, cache-version, or golden change is included.

Java has no anchor population, so no after percentage is invented. The valid
quick head run was slower than the valid base run, but the base was warmed by
the earlier invalid attempt and the head was not; the single timing comparison
is confounded and is not attributed as a regression. Informational C remains in
the middle band and is outside the §7.1 gate.
