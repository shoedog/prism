### Task 2: Reaching-definitions core pass, unwired

**Acceptance (spec §10 row 2):** §7.2 RD unit tests — diamond, loop, `kill_line`, caps, no-CFG — GREEN.

**Files:**

- Create: `src/cpg/reaching.rs` (strictly < 600 lines including tests; split before reaching 600).
- Modify: `src/cpg.rs` only to register the module.
- Read only: `src/cfg.rs`, `src/ast.rs`, `src/data_flow.rs`, `src/access_path.rs`.

**Interfaces:**

- Consumes: `cfg::build_cfg_edges_with_arms` (Task 0), `ParsedFile::statements_in_function` (`src/ast.rs:5778`), `ParsedFile::assignment_lvalue_spans_on_lines` (`:3609`), function parameter occurrences (`src/data_flow.rs:266-291`), `AccessPath`, and the alias semantics of `DataFlowGraph::build_alias_map` (`src/data_flow.rs:583`) / `resolve_path` (`:643`).
- **Bound before RED (not negotiable):**

```rust
/// Hard caps from the authorised measurement pass
/// (~/code/tools/logs/item2-census/REPORT.md §2.3, 92,338 functions).
/// RD_MAX_LINES bounds `stmt_lines.len()` — the CFG statement-line universe
/// returned by `ParsedFile::statements_in_function` — NOT the function's line
/// span (`end - start + 1`). Measured worst case: 590 defs, 331 statement
/// lines; 0 of 92,338 functions exceed either cap.
pub(crate) const RD_MAX_DEFS: usize = 2048;
pub(crate) const RD_MAX_LINES: usize = 4096;
```

  Also bound: `FlowConfidence` / `FlowDoubt` (Task 1) and the `labels` key shape `(VarLocation, VarLocation)` (Task 3).
- **Bound by sol r1 W3:** `Unavailable` must carry a **cap-specific reason** with **two distinguishable values** — one for the def cap, one for the line cap — so a test can prove *which* check fired. The exact shape is the implementer's proposal under B2 (an enum variant, a field, whatever fits); the requirement is that `over_cap_statement_lines_*` and `over_cap_defs_*` assert *different* observable reasons. Without this, a fixture of 4,097 assignment statements also exceeds `RD_MAX_DEFS`, and an implementation that never checks the line cap passes the line-cap test through the def cap.
- **Bound at Step 1 by the controller (owner B2):** the exact Rust signature of the RD entry point and its private types (`DefSite`, `DefId`, `Line`, `Unavailable`). The §4.2 pseudocode is binding for **semantics**, not signatures.

**Steps:**

- [ ] **Step 1: Propose the signatures; get controller approval; paste them here.** Write a task report containing the exact declarations, e.g. in this shape, and **do not proceed until the controller approves or amends**:

```rust
// PROPOSAL — controller fills in / amends, then this block becomes binding.
pub(crate) struct DefSite { pub id: DefId, pub path: AccessPath, pub line: Line, pub start_byte: usize, pub alias_derived: bool }
pub(crate) struct DefId(u32);
pub(crate) type Line = usize;
pub(crate) enum RdOutcome { Available(RdResult), Unavailable(RdUnavailable) }
pub(crate) enum RdUnavailable { OverCap, NoCfgEdges }
pub(crate) struct RdResult { /* IN sets per line, kill_at per def, same-line groups, capture set */ }
pub(crate) fn reaching_definitions(parsed: &ParsedFile, func_node: &Node<'_>, defs: &[DefSite], alias_map: &BTreeMap<String, String>) -> RdOutcome;
```

The report must say, for each private type, what §4.2 pseudocode line it realises. A guessed signature is a plan violation.

- [ ] **Step 2: Write failing GEN/KILL tests.**

```rust
#[test]
fn same_path_redefinition_kills_the_earlier_def() {
    // x = A (2); x = B (3); use(x) (4)  ->  A killed at 3, B live at 4
}
#[test]
fn alias_derived_defs_never_kill_in_v1() {
    // p = q; p.x = 1; q.x = 2; use(q.x)
    // v1 never uses a flow-insensitive alias relation as a kill proof (§4.2 line 14).
}
#[test]
fn same_line_defs_never_kill_one_another_by_byte_order() {
    // a = 1; a = 2;  on ONE physical line -> both marked collapsed; neither kills
    // the other; `start_byte`/`end_byte` are never compared (§4.3, owner B8 iii).
}
```

- [ ] **Step 3: Write failing fixpoint tests.**

```rust
#[test]
fn diamond_kill_on_one_branch_still_reaches() {
    // x=A; if c { x=B } else { }; use(x)
    // Standard RD union at the meet: A reaches along the else path -> Exact (§6 rule 4).
}
#[test]
fn loop_back_edge_makes_a_textually_earlier_use_reachable() {
    // for ...: use(x); x = f()
    // `collect_loop_back_edges` (src/cfg.rs:247) already supplies the back edge,
    // so the later def lands in IN[earlier use] -> Exact + loop_carried telemetry.
}
#[test]
fn kill_line_is_the_lowest_reachable_killing_line() {
    // x=A(2); if c { x=B(4) } else { x=C(6) }; use(x)(8)
    // kill_line == 4, not 6, and not the max.
}
#[test]
fn an_unreachable_kill_does_not_supply_the_payload() {
    // a killing redefinition on a branch that cannot be reached from the def
}
```

- [ ] **Step 4: Write failing availability tests — three DECOUPLED cap fixtures (sol r1 W3).**

Each cap fixture varies **one** quantity and holds the other below its cap, and each asserts the **cap-specific reason**, so neither check can pass through the other:

```rust
/// (a) LINE CAP, with the def count held at ZERO. 4,097 statement lines that
/// generate no Defs at all — bare calls, not assignments — so `defs.len() == 0`
/// and `RD_MAX_DEFS` cannot possibly fire. If the implementation omits the
/// `stmt_lines.len()` check this test fails, which is the whole point: a
/// fixture of 4,097 *assignments* would also blow the def cap and let a
/// line-cap-blind implementation pass.
#[test]
fn over_cap_statement_lines_returns_unavailable_for_the_lines_reason() {
    let mut src = String::from("def f():\n");
    for _ in 0..4097 { src.push_str("    g()\n"); }   // statements, zero Defs
    let (outcome, stats) = run_rd_on_single_function(&src, Language::Python);
    assert_eq!(defs_len(&src), 0, "fixture must generate zero Defs, else the def cap confounds this test");
    assert_eq!(stmt_lines_len(&src), 4097);
    assert!(
        matches!(outcome, RdOutcome::Unavailable(r) if r.is_line_cap()),
        "expected the LINE-cap reason, got {outcome:?}"
    );
    assert_eq!(stats.functions_over_cap, 1);
}

/// (b) DEF CAP, with the statement-line count held UNDER 4,096. 2,049 Defs
/// packed onto ~700 statement lines (three assignments per line), so
/// `RD_MAX_LINES` cannot fire and only the def check can explain the result.
#[test]
fn over_cap_defs_returns_unavailable_for_the_defs_reason() {
    let mut src = String::from("def f():\n");
    for i in 0..683 { src.push_str(&format!("    a{i} = 1; b{i} = 2; c{i} = 3\n")); }
    let (outcome, stats) = run_rd_on_single_function(&src, Language::Python);
    assert!(defs_len(&src) > 2048);
    assert!(stmt_lines_len(&src) <= 4096, "fixture must stay under the line cap");
    assert!(
        matches!(outcome, RdOutcome::Unavailable(r) if r.is_def_cap()),
        "expected the DEF-cap reason, got {outcome:?}"
    );
    assert_eq!(stats.functions_over_cap, 1);
}

/// (c) LONG SPAN with few of both. RD_MAX_LINES bounds `stmt_lines.len()`, NOT
/// the function's line span. ~5,000 source lines that are almost all comments
/// and blanks, leaving ~20 statement lines and ~10 Defs. (REPORT.md §2.3: under
/// the *span* reading the observed maximum is 3,296 and two of 92,338 functions
/// exceed 2048 — a different question, deliberately not the one the cap asks.)
#[test]
fn a_long_span_with_few_statements_and_few_defs_is_not_unavailable() {
    let outcome = run_rd_on_single_function(&long_span_source(5000, 20, 10), Language::Python).0;
    assert!(matches!(outcome, RdOutcome::Available(_)), "got {outcome:?}");
}

#[test]
fn cap_poles_remain_runnable() {
    // exactly 2048 Defs (under 4096 lines) -> Available
    // exactly 4096 statement lines (zero Defs) -> Available
}

#[test]
fn zero_cfg_edge_function_returns_unavailable_for_the_no_cfg_reason() {
    // build_function_cfg returns early on an empty statement list
    // (src/cfg.rs:40-42) -> a reason distinct from both cap reasons, and
    // functions_without_cfg == 1 while functions_over_cap == 0.
}
```

- [ ] **Step 5: Write failing capture-classification tests.** Minimal parsed sources for: Python `lambda` and nested `def`; Go `defer`/`go` function literal; JS/TS arrow and `function`; Rust closure. Assert each captured outer-binding read inside the delayed body classifies incomplete. Assert the paired negative: **`defer f(x)` evaluates `x` now**, so it is an ordinary argument read and remains eligible for its normal RD label (§4.2, §7.1 `dfg_reaching_defer_argument_now`). Each test's name states which construct made the timing unknown (owner B8 (i)).

- [ ] **Step 6: Run RED — both parts (RED-shape rule).**

**Part 1 — feature absence.** Run `cargo test --lib cpg::reaching::tests`. Expected: compile error, module absent. Record as **feature absent**; not the RED.

**Part 2 — assertion-level failure against a conservative stub.**

**Symbol closure (sol r2 W1).** `cargo test --lib cpg::reaching::tests` exercises:

| Symbol the tests exercise | Provided by |
|---|---|
| `RdOutcome`, `RdUnavailable`, `RdResult`, `DefSite`, `DefId`, `Line` | **Step 1's controller-approved declarations** — they land in the module before any test is written |
| `RdUnavailable::is_line_cap()` / `is_def_cap()` (two distinguishable reasons) | Step 1's approved shape; if the approved shape uses match patterns instead of predicates, the tests use those patterns — the requirement is only that the two reasons are distinguishable |
| `reaching_definitions(...)` | **stub** |
| `RD_MAX_DEFS`, `RD_MAX_LINES` | **bound in Interfaces** |
| in-module test helpers `run_rd_on_single_function`, `defs_len`, `stmt_lines_len`, `long_span_source` | written with the tests in Steps 2-5; `run_rd_on_single_function` parses the source, collects `DefSite`s, calls `reaching_definitions`, and tallies `RdFileStats` |
| `RdFileStats { functions_over_cap, functions_without_cfg }` | Task 3's Interfaces; declared here in Step 1 so the counters are assertable |
| `ParsedFile::parse`, `Language::Python`, `Node`, `AccessPath`, `BTreeMap` | **exists** |

Add the smallest stub that compiles and answers pessimistically everywhere:

```rust
/// STUB — every function is Unavailable with the no-CFG reason and no labels.
/// Conservative (nothing is ever Exact) and deliberately wrong. Replaced in Step 7.
pub(crate) fn reaching_definitions(
    _parsed: &ParsedFile, _func_node: &Node<'_>, _defs: &[DefSite],
    _alias_map: &BTreeMap<String, String>,
) -> RdOutcome {
    RdOutcome::Unavailable(RdUnavailable::NoCfgEdges)
}
```

Run the same command. Expected assertion failures, each naming values:
- `over_cap_statement_lines_returns_unavailable_for_the_lines_reason` — `Unavailable`, but the **wrong reason** (`NoCfgEdges`, not the line-cap reason). This is exactly the discrimination W3 asked for: a stub that returns `Unavailable` unconditionally must not be able to pass a cap test.
- `over_cap_defs_returns_unavailable_for_the_defs_reason` — same, wrong reason.
- `a_long_span_with_few_statements_and_few_defs_is_not_unavailable` and `cap_poles_remain_runnable` — got `Unavailable`, expected `Available`.
- Every GEN/KILL, diamond, loop, `kill_line`, same-line and capture test — no labels produced.
- `zero_cfg_edge_function_returns_unavailable_for_the_no_cfg_reason` **passes** against the stub. Record that: it is the one test the stub satisfies by accident, and it is therefore the weakest of the set on its own.

Preserve both observations in the task report.

- [ ] **Step 7: Implement §4.2 exactly.** Synthetic ENTRY at the function start line with `succ(ENTRY) = {first(stmt_lines)}` — parameter Defs are pinned to the signature line (`src/data_flow.rs:274`), which is **not** in `stmt_lines` because `collect_statements` walks the body (`src/ast.rs:5785`). CFG adjacency from `build_cfg_edges_with_arms` restricted to this function's line range. Fixed-width bit-vectors of width `defs.len()` (REPORT.md §2.2: the largest observed function needs 5.4 KiB per family; do **not** switch to a sparse `BTreeSet<DefId>` — REPORT.md §2.3 shows its trigger fires on zero functions and at p90 a dense vector is one `u64`). GEN/KILL per §4.2 lines 10-14. Worklist fixpoint in reverse postorder from ENTRY, `IN[L] = ⋃ OUT[P]` over predecessors **including back edges**.

- [ ] **Step 8: Implement the labeling precedence exactly** (§4.3): capture/deferred-body `CfgIncomplete` > ordinary `CfgIncomplete` > `SameLine` > `AliasUnstable` > `Killed`. A reason that says "RD could not run" must never be reported as "RD proved a kill". An edge crossing a flagged CFG join — try-header exception/finally (`src/cfg.rs:337-365`, `:525-570`), Go synthetic return→defer (`:379`), or `ArmProvenance::crosses_lexical_arm()` from Task 0 — is `NameOnly(CfgIncomplete)`.

- [ ] **Step 9: Implement same-line grouping** on `(AccessPath, line)` at line-granular identity; mark **every** member of a group with ≥2 Defs; never compare `start_byte`/`end_byte` to pick a winner.

- [ ] **Step 10: Run GREEN.**

Run: `cargo test --lib cpg::reaching::tests`
Expected: every GEN/KILL, diamond, loop, `kill_line`, cap, span-vs-statement-count, no-CFG, same-line, capture, and immediate-defer case passes.

- [ ] **Step 11: Gates.** `cargo fmt --all -- --check`; `cargo clippy --lib --all-features -- -D warnings`. No byte control is required — the pass is not wired and cannot change output.

- [ ] **Step 12: Commit.**

```bash
git add src/cpg/reaching.rs src/cpg.rs
git commit -m "feat(item2): add the reaching-definitions core" \
  -m "Co-Authored-By: Claude Fable 5.1 <noreply@anthropic.com>" \
  -m "Claude-Session: https://claude.ai/code/session_015U8HwBTAFzFzqJbbq82JBT"
```

---

